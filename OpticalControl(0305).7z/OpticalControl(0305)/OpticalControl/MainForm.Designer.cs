﻿
namespace OpticalControl
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 設計工具產生的程式碼

        /// <summary>
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器修改
        /// 這個方法的內容。
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.TbxWdiDefZ = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.BtnAFMove = new System.Windows.Forms.Button();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.BtnWdiGetSubStrate = new System.Windows.Forms.Button();
            this.TbxWdiSubstrate = new System.Windows.Forms.TextBox();
            this.Cbx_WdiSubStrate = new System.Windows.Forms.ComboBox();
            this.BtnWdiSetSubStrate = new System.Windows.Forms.Button();
            this.BtnWdiOff = new System.Windows.Forms.Button();
            this.TbxWdiLimitU = new System.Windows.Forms.TextBox();
            this.BtnWdiHome = new System.Windows.Forms.Button();
            this.TbxWdiLimitL = new System.Windows.Forms.TextBox();
            this.BtnWdiRead = new System.Windows.Forms.Button();
            this.BtnWdiOn = new System.Windows.Forms.Button();
            this.TbxWdiPos = new System.Windows.Forms.TextBox();
            this.TabCtrl = new System.Windows.Forms.TabControl();
            this.PageWDI = new System.Windows.Forms.TabPage();
            this.Tbx_WDIAF_uPWM = new System.Windows.Forms.TextBox();
            this.Tbx_WDIAF_Current = new System.Windows.Forms.TextBox();
            this.label19 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.Btn_WDIAF_SetLED = new System.Windows.Forms.Button();
            this.Tbx_WDIAF_Channel = new System.Windows.Forms.TextBox();
            this.label17 = new System.Windows.Forms.Label();
            this.PageWDILED = new System.Windows.Forms.TabPage();
            this.TbxDuration = new System.Windows.Forms.TextBox();
            this.TbxTriggerDelay = new System.Windows.Forms.TextBox();
            this.label20 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.BtnLEDSendCMD = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.Rbtn_PaulseTrigger = new System.Windows.Forms.RadioButton();
            this.Rbtn_Off = new System.Windows.Forms.RadioButton();
            this.Rbtn_PaulseFollow = new System.Windows.Forms.RadioButton();
            this.Rbtn_DC = new System.Windows.Forms.RadioButton();
            this.TbxBrightness = new System.Windows.Forms.TextBox();
            this.BarBrightness = new System.Windows.Forms.TrackBar();
            this.label7 = new System.Windows.Forms.Label();
            this.PageLight = new System.Windows.Forms.TabPage();
            this.Btn_DarkField_Send = new System.Windows.Forms.Button();
            this.Ckx_DarkField_ErrorDetect = new System.Windows.Forms.CheckBox();
            this.Ckx_DarkField_Autosense = new System.Windows.Forms.CheckBox();
            this.Ckx_DarkField_PosTrigger = new System.Windows.Forms.CheckBox();
            this.Tbx_DarkField_OuputCurrent = new System.Windows.Forms.TextBox();
            this.Tbx_DarkField_ReTriggerDelay = new System.Windows.Forms.TextBox();
            this.Tbx_DarkField_TriggerDelay = new System.Windows.Forms.TextBox();
            this.Tbx_DarkField_PulseWidth = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.Cbx_DarkField_Channel = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.PageRevo = new System.Windows.Forms.TabPage();
            this.Btn_Revo_ReadStatus = new System.Windows.Forms.Button();
            this.Tbx_Revo_SensorStatus = new System.Windows.Forms.TextBox();
            this.Tbx_Revo_Version = new System.Windows.Forms.TextBox();
            this.Tbx_Revo_ConnectionStatus = new System.Windows.Forms.TextBox();
            this.Tbx_Revo_Communication = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.Tbx_Revo_OperationStatus = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.Btn_Revo_Stop = new System.Windows.Forms.Button();
            this.Btn_Revo_Move = new System.Windows.Forms.Button();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.Rbtn_Revo_D = new System.Windows.Forms.RadioButton();
            this.Rbtn_Revo_C = new System.Windows.Forms.RadioButton();
            this.Rbtn_Revo_B = new System.Windows.Forms.RadioButton();
            this.Rbtn_Revo_A = new System.Windows.Forms.RadioButton();
            this.PageConfig = new System.Windows.Forms.TabPage();
            this.PGrid_Config = new System.Windows.Forms.PropertyGrid();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.BtnSaveConfig = new System.Windows.Forms.ToolStripMenuItem();
            this.PageVersion = new System.Windows.Forms.TabPage();
            this.RTbxVersion = new System.Windows.Forms.RichTextBox();
            this.RichTbx_Log_Main = new System.Windows.Forms.RichTextBox();
            this.BtnZoom = new System.Windows.Forms.Button();
            this.LabelAF = new System.Windows.Forms.Label();
            this.LabelLED = new System.Windows.Forms.Label();
            this.LabelDarkField = new System.Windows.Forms.Label();
            this.LabelRevo = new System.Windows.Forms.Label();
            this.LabelSvr = new System.Windows.Forms.Label();
            this.groupBox4.SuspendLayout();
            this.TabCtrl.SuspendLayout();
            this.PageWDI.SuspendLayout();
            this.PageWDILED.SuspendLayout();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.BarBrightness)).BeginInit();
            this.PageLight.SuspendLayout();
            this.PageRevo.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.PageConfig.SuspendLayout();
            this.contextMenuStrip1.SuspendLayout();
            this.PageVersion.SuspendLayout();
            this.SuspendLayout();
            // 
            // TbxWdiDefZ
            // 
            this.TbxWdiDefZ.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.TbxWdiDefZ.Location = new System.Drawing.Point(133, 91);
            this.TbxWdiDefZ.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.TbxWdiDefZ.Name = "TbxWdiDefZ";
            this.TbxWdiDefZ.Size = new System.Drawing.Size(76, 29);
            this.TbxWdiDefZ.TabIndex = 29;
            this.TbxWdiDefZ.Text = "-1000";
            this.TbxWdiDefZ.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label2.Location = new System.Drawing.Point(7, 94);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(118, 21);
            this.label2.TabIndex = 28;
            this.label2.Text = "AF Z 位置(um)";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label4.Location = new System.Drawing.Point(7, 172);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(111, 21);
            this.label4.TabIndex = 25;
            this.label4.Text = "範圍下限(um)";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label3.Location = new System.Drawing.Point(5, 133);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(111, 21);
            this.label3.TabIndex = 24;
            this.label3.Text = "範圍上限(um)";
            // 
            // BtnAFMove
            // 
            this.BtnAFMove.BackColor = System.Drawing.SystemColors.Control;
            this.BtnAFMove.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.BtnAFMove.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.BtnAFMove.Location = new System.Drawing.Point(217, 90);
            this.BtnAFMove.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.BtnAFMove.Name = "BtnAFMove";
            this.BtnAFMove.Size = new System.Drawing.Size(111, 34);
            this.BtnAFMove.TabIndex = 22;
            this.BtnAFMove.Text = "Move";
            this.BtnAFMove.UseVisualStyleBackColor = false;
            this.BtnAFMove.Click += new System.EventHandler(this.BtnAFMove_Click);
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.BtnWdiGetSubStrate);
            this.groupBox4.Controls.Add(this.TbxWdiSubstrate);
            this.groupBox4.Controls.Add(this.Cbx_WdiSubStrate);
            this.groupBox4.Controls.Add(this.BtnWdiSetSubStrate);
            this.groupBox4.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.groupBox4.ForeColor = System.Drawing.SystemColors.Control;
            this.groupBox4.Location = new System.Drawing.Point(85, 10);
            this.groupBox4.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox4.Size = new System.Drawing.Size(292, 68);
            this.groupBox4.TabIndex = 20;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Substrate";
            // 
            // BtnWdiGetSubStrate
            // 
            this.BtnWdiGetSubStrate.BackColor = System.Drawing.SystemColors.Control;
            this.BtnWdiGetSubStrate.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.BtnWdiGetSubStrate.Location = new System.Drawing.Point(215, 24);
            this.BtnWdiGetSubStrate.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.BtnWdiGetSubStrate.Name = "BtnWdiGetSubStrate";
            this.BtnWdiGetSubStrate.Size = new System.Drawing.Size(69, 33);
            this.BtnWdiGetSubStrate.TabIndex = 21;
            this.BtnWdiGetSubStrate.Text = "Get";
            this.BtnWdiGetSubStrate.UseVisualStyleBackColor = false;
            this.BtnWdiGetSubStrate.Click += new System.EventHandler(this.BtnWdiGetSubStrate_Click);
            // 
            // TbxWdiSubstrate
            // 
            this.TbxWdiSubstrate.Enabled = false;
            this.TbxWdiSubstrate.Location = new System.Drawing.Point(159, 25);
            this.TbxWdiSubstrate.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.TbxWdiSubstrate.Name = "TbxWdiSubstrate";
            this.TbxWdiSubstrate.Size = new System.Drawing.Size(48, 29);
            this.TbxWdiSubstrate.TabIndex = 21;
            this.TbxWdiSubstrate.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // Cbx_WdiSubStrate
            // 
            this.Cbx_WdiSubStrate.FormattingEnabled = true;
            this.Cbx_WdiSubStrate.Items.AddRange(new object[] {
            "A",
            "B",
            "C",
            "D",
            "E"});
            this.Cbx_WdiSubStrate.Location = new System.Drawing.Point(14, 24);
            this.Cbx_WdiSubStrate.Margin = new System.Windows.Forms.Padding(4);
            this.Cbx_WdiSubStrate.Name = "Cbx_WdiSubStrate";
            this.Cbx_WdiSubStrate.Size = new System.Drawing.Size(45, 29);
            this.Cbx_WdiSubStrate.TabIndex = 21;
            // 
            // BtnWdiSetSubStrate
            // 
            this.BtnWdiSetSubStrate.BackColor = System.Drawing.SystemColors.Control;
            this.BtnWdiSetSubStrate.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.BtnWdiSetSubStrate.Location = new System.Drawing.Point(67, 24);
            this.BtnWdiSetSubStrate.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.BtnWdiSetSubStrate.Name = "BtnWdiSetSubStrate";
            this.BtnWdiSetSubStrate.Size = new System.Drawing.Size(69, 33);
            this.BtnWdiSetSubStrate.TabIndex = 20;
            this.BtnWdiSetSubStrate.Text = "Set";
            this.BtnWdiSetSubStrate.UseVisualStyleBackColor = false;
            this.BtnWdiSetSubStrate.Click += new System.EventHandler(this.BtnWdiSetSubStrate_Click);
            // 
            // BtnWdiOff
            // 
            this.BtnWdiOff.BackColor = System.Drawing.SystemColors.Control;
            this.BtnWdiOff.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.BtnWdiOff.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.BtnWdiOff.Location = new System.Drawing.Point(296, 134);
            this.BtnWdiOff.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.BtnWdiOff.Name = "BtnWdiOff";
            this.BtnWdiOff.Size = new System.Drawing.Size(72, 64);
            this.BtnWdiOff.TabIndex = 10;
            this.BtnWdiOff.Text = "AF Off";
            this.BtnWdiOff.UseVisualStyleBackColor = false;
            this.BtnWdiOff.Click += new System.EventHandler(this.BtnWdiOff_Click);
            // 
            // TbxWdiLimitU
            // 
            this.TbxWdiLimitU.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.TbxWdiLimitU.Location = new System.Drawing.Point(133, 130);
            this.TbxWdiLimitU.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.TbxWdiLimitU.Name = "TbxWdiLimitU";
            this.TbxWdiLimitU.Size = new System.Drawing.Size(76, 29);
            this.TbxWdiLimitU.TabIndex = 15;
            this.TbxWdiLimitU.Text = "150";
            this.TbxWdiLimitU.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // BtnWdiHome
            // 
            this.BtnWdiHome.BackColor = System.Drawing.SystemColors.Control;
            this.BtnWdiHome.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.BtnWdiHome.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.BtnWdiHome.Location = new System.Drawing.Point(7, 10);
            this.BtnWdiHome.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.BtnWdiHome.Name = "BtnWdiHome";
            this.BtnWdiHome.Size = new System.Drawing.Size(70, 68);
            this.BtnWdiHome.TabIndex = 18;
            this.BtnWdiHome.Text = "AF Home";
            this.BtnWdiHome.UseVisualStyleBackColor = false;
            this.BtnWdiHome.Click += new System.EventHandler(this.BtnWdiHome_Click);
            // 
            // TbxWdiLimitL
            // 
            this.TbxWdiLimitL.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.TbxWdiLimitL.Location = new System.Drawing.Point(133, 169);
            this.TbxWdiLimitL.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.TbxWdiLimitL.Name = "TbxWdiLimitL";
            this.TbxWdiLimitL.Size = new System.Drawing.Size(76, 29);
            this.TbxWdiLimitL.TabIndex = 16;
            this.TbxWdiLimitL.Text = "-150";
            this.TbxWdiLimitL.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // BtnWdiRead
            // 
            this.BtnWdiRead.BackColor = System.Drawing.SystemColors.Control;
            this.BtnWdiRead.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.BtnWdiRead.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.BtnWdiRead.Location = new System.Drawing.Point(11, 216);
            this.BtnWdiRead.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.BtnWdiRead.Name = "BtnWdiRead";
            this.BtnWdiRead.Size = new System.Drawing.Size(94, 32);
            this.BtnWdiRead.TabIndex = 11;
            this.BtnWdiRead.Text = "Read Pos";
            this.BtnWdiRead.UseVisualStyleBackColor = false;
            this.BtnWdiRead.Click += new System.EventHandler(this.BtnWdiRead_Click);
            // 
            // BtnWdiOn
            // 
            this.BtnWdiOn.BackColor = System.Drawing.SystemColors.Control;
            this.BtnWdiOn.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.BtnWdiOn.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.BtnWdiOn.Location = new System.Drawing.Point(217, 133);
            this.BtnWdiOn.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.BtnWdiOn.Name = "BtnWdiOn";
            this.BtnWdiOn.Size = new System.Drawing.Size(71, 65);
            this.BtnWdiOn.TabIndex = 9;
            this.BtnWdiOn.Text = "AF On";
            this.BtnWdiOn.UseVisualStyleBackColor = false;
            this.BtnWdiOn.Click += new System.EventHandler(this.BtnWdiOn_Click);
            // 
            // TbxWdiPos
            // 
            this.TbxWdiPos.BackColor = System.Drawing.SystemColors.Control;
            this.TbxWdiPos.Enabled = false;
            this.TbxWdiPos.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.TbxWdiPos.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.TbxWdiPos.Location = new System.Drawing.Point(113, 219);
            this.TbxWdiPos.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.TbxWdiPos.Name = "TbxWdiPos";
            this.TbxWdiPos.Size = new System.Drawing.Size(117, 29);
            this.TbxWdiPos.TabIndex = 17;
            this.TbxWdiPos.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // TabCtrl
            // 
            this.TabCtrl.Appearance = System.Windows.Forms.TabAppearance.FlatButtons;
            this.TabCtrl.Controls.Add(this.PageWDI);
            this.TabCtrl.Controls.Add(this.PageWDILED);
            this.TabCtrl.Controls.Add(this.PageLight);
            this.TabCtrl.Controls.Add(this.PageRevo);
            this.TabCtrl.Controls.Add(this.PageConfig);
            this.TabCtrl.Controls.Add(this.PageVersion);
            this.TabCtrl.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.TabCtrl.Location = new System.Drawing.Point(4, 276);
            this.TabCtrl.Multiline = true;
            this.TabCtrl.Name = "TabCtrl";
            this.TabCtrl.SelectedIndex = 0;
            this.TabCtrl.Size = new System.Drawing.Size(494, 293);
            this.TabCtrl.TabIndex = 25;
            // 
            // PageWDI
            // 
            this.PageWDI.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.PageWDI.Controls.Add(this.Tbx_WDIAF_uPWM);
            this.PageWDI.Controls.Add(this.Tbx_WDIAF_Current);
            this.PageWDI.Controls.Add(this.label19);
            this.PageWDI.Controls.Add(this.label18);
            this.PageWDI.Controls.Add(this.Btn_WDIAF_SetLED);
            this.PageWDI.Controls.Add(this.Tbx_WDIAF_Channel);
            this.PageWDI.Controls.Add(this.label17);
            this.PageWDI.Controls.Add(this.BtnWdiHome);
            this.PageWDI.Controls.Add(this.TbxWdiPos);
            this.PageWDI.Controls.Add(this.BtnWdiOn);
            this.PageWDI.Controls.Add(this.groupBox4);
            this.PageWDI.Controls.Add(this.BtnWdiRead);
            this.PageWDI.Controls.Add(this.TbxWdiDefZ);
            this.PageWDI.Controls.Add(this.TbxWdiLimitL);
            this.PageWDI.Controls.Add(this.label2);
            this.PageWDI.Controls.Add(this.TbxWdiLimitU);
            this.PageWDI.Controls.Add(this.label4);
            this.PageWDI.Controls.Add(this.BtnWdiOff);
            this.PageWDI.Controls.Add(this.label3);
            this.PageWDI.Controls.Add(this.BtnAFMove);
            this.PageWDI.Location = new System.Drawing.Point(4, 33);
            this.PageWDI.Name = "PageWDI";
            this.PageWDI.Padding = new System.Windows.Forms.Padding(3);
            this.PageWDI.Size = new System.Drawing.Size(486, 256);
            this.PageWDI.TabIndex = 0;
            this.PageWDI.Text = "WDI 對焦";
            // 
            // Tbx_WDIAF_uPWM
            // 
            this.Tbx_WDIAF_uPWM.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.Tbx_WDIAF_uPWM.Location = new System.Drawing.Point(406, 180);
            this.Tbx_WDIAF_uPWM.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Tbx_WDIAF_uPWM.Name = "Tbx_WDIAF_uPWM";
            this.Tbx_WDIAF_uPWM.Size = new System.Drawing.Size(73, 29);
            this.Tbx_WDIAF_uPWM.TabIndex = 38;
            this.Tbx_WDIAF_uPWM.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // Tbx_WDIAF_Current
            // 
            this.Tbx_WDIAF_Current.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.Tbx_WDIAF_Current.Location = new System.Drawing.Point(406, 123);
            this.Tbx_WDIAF_Current.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Tbx_WDIAF_Current.Name = "Tbx_WDIAF_Current";
            this.Tbx_WDIAF_Current.Size = new System.Drawing.Size(73, 29);
            this.Tbx_WDIAF_Current.TabIndex = 37;
            this.Tbx_WDIAF_Current.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label19.Location = new System.Drawing.Point(414, 157);
            this.label19.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(63, 21);
            this.label19.TabIndex = 36;
            this.label19.Text = "uPWM";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label18.Location = new System.Drawing.Point(408, 100);
            this.label18.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(68, 21);
            this.label18.TabIndex = 35;
            this.label18.Text = "Current";
            // 
            // Btn_WDIAF_SetLED
            // 
            this.Btn_WDIAF_SetLED.BackColor = System.Drawing.SystemColors.Control;
            this.Btn_WDIAF_SetLED.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.Btn_WDIAF_SetLED.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.Btn_WDIAF_SetLED.Location = new System.Drawing.Point(391, 219);
            this.Btn_WDIAF_SetLED.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Btn_WDIAF_SetLED.Name = "Btn_WDIAF_SetLED";
            this.Btn_WDIAF_SetLED.Size = new System.Drawing.Size(86, 29);
            this.Btn_WDIAF_SetLED.TabIndex = 34;
            this.Btn_WDIAF_SetLED.Text = "Set LED";
            this.Btn_WDIAF_SetLED.UseVisualStyleBackColor = false;
            this.Btn_WDIAF_SetLED.Click += new System.EventHandler(this.Btn_WDIAF_SetLED_Click);
            // 
            // Tbx_WDIAF_Channel
            // 
            this.Tbx_WDIAF_Channel.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.Tbx_WDIAF_Channel.Location = new System.Drawing.Point(406, 66);
            this.Tbx_WDIAF_Channel.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Tbx_WDIAF_Channel.Name = "Tbx_WDIAF_Channel";
            this.Tbx_WDIAF_Channel.Size = new System.Drawing.Size(73, 29);
            this.Tbx_WDIAF_Channel.TabIndex = 33;
            this.Tbx_WDIAF_Channel.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label17.Location = new System.Drawing.Point(406, 43);
            this.label17.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(73, 21);
            this.label17.TabIndex = 32;
            this.label17.Text = "Channel";
            // 
            // PageWDILED
            // 
            this.PageWDILED.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.PageWDILED.Controls.Add(this.TbxDuration);
            this.PageWDILED.Controls.Add(this.TbxTriggerDelay);
            this.PageWDILED.Controls.Add(this.label20);
            this.PageWDILED.Controls.Add(this.label5);
            this.PageWDILED.Controls.Add(this.BtnLEDSendCMD);
            this.PageWDILED.Controls.Add(this.groupBox1);
            this.PageWDILED.Controls.Add(this.TbxBrightness);
            this.PageWDILED.Controls.Add(this.BarBrightness);
            this.PageWDILED.Controls.Add(this.label7);
            this.PageWDILED.Location = new System.Drawing.Point(4, 33);
            this.PageWDILED.Name = "PageWDILED";
            this.PageWDILED.Padding = new System.Windows.Forms.Padding(3);
            this.PageWDILED.Size = new System.Drawing.Size(486, 256);
            this.PageWDILED.TabIndex = 1;
            this.PageWDILED.Text = "WDI LED";
            // 
            // TbxDuration
            // 
            this.TbxDuration.Location = new System.Drawing.Point(190, 207);
            this.TbxDuration.Name = "TbxDuration";
            this.TbxDuration.Size = new System.Drawing.Size(141, 29);
            this.TbxDuration.TabIndex = 47;
            // 
            // TbxTriggerDelay
            // 
            this.TbxTriggerDelay.Location = new System.Drawing.Point(24, 208);
            this.TbxTriggerDelay.Name = "TbxTriggerDelay";
            this.TbxTriggerDelay.Size = new System.Drawing.Size(141, 29);
            this.TbxTriggerDelay.TabIndex = 46;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(196, 184);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(111, 21);
            this.label20.TabIndex = 45;
            this.label20.Text = "Duration (us)";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(20, 184);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(145, 21);
            this.label5.TabIndex = 44;
            this.label5.Text = "Trigger Delay (us)";
            // 
            // BtnLEDSendCMD
            // 
            this.BtnLEDSendCMD.BackColor = System.Drawing.SystemColors.Control;
            this.BtnLEDSendCMD.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.BtnLEDSendCMD.ForeColor = System.Drawing.Color.Black;
            this.BtnLEDSendCMD.Location = new System.Drawing.Point(365, 172);
            this.BtnLEDSendCMD.Name = "BtnLEDSendCMD";
            this.BtnLEDSendCMD.Size = new System.Drawing.Size(98, 64);
            this.BtnLEDSendCMD.TabIndex = 43;
            this.BtnLEDSendCMD.Text = "Send CMD";
            this.BtnLEDSendCMD.UseVisualStyleBackColor = false;
            this.BtnLEDSendCMD.Click += new System.EventHandler(this.BtnLEDSendCMD_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.Rbtn_PaulseTrigger);
            this.groupBox1.Controls.Add(this.Rbtn_Off);
            this.groupBox1.Controls.Add(this.Rbtn_PaulseFollow);
            this.groupBox1.Controls.Add(this.Rbtn_DC);
            this.groupBox1.ForeColor = System.Drawing.SystemColors.Control;
            this.groupBox1.Location = new System.Drawing.Point(6, 6);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(210, 160);
            this.groupBox1.TabIndex = 42;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "LED Mode";
            // 
            // Rbtn_PaulseTrigger
            // 
            this.Rbtn_PaulseTrigger.AutoSize = true;
            this.Rbtn_PaulseTrigger.Checked = true;
            this.Rbtn_PaulseTrigger.Location = new System.Drawing.Point(18, 92);
            this.Rbtn_PaulseTrigger.Name = "Rbtn_PaulseTrigger";
            this.Rbtn_PaulseTrigger.Size = new System.Drawing.Size(180, 25);
            this.Rbtn_PaulseTrigger.TabIndex = 3;
            this.Rbtn_PaulseTrigger.TabStop = true;
            this.Rbtn_PaulseTrigger.Text = "Pulse Trigger  Mode";
            this.Rbtn_PaulseTrigger.UseVisualStyleBackColor = true;
            // 
            // Rbtn_Off
            // 
            this.Rbtn_Off.AutoSize = true;
            this.Rbtn_Off.Location = new System.Drawing.Point(18, 123);
            this.Rbtn_Off.Name = "Rbtn_Off";
            this.Rbtn_Off.Size = new System.Drawing.Size(53, 25);
            this.Rbtn_Off.TabIndex = 2;
            this.Rbtn_Off.Text = "Off";
            this.Rbtn_Off.UseVisualStyleBackColor = true;
            // 
            // Rbtn_PaulseFollow
            // 
            this.Rbtn_PaulseFollow.AutoSize = true;
            this.Rbtn_PaulseFollow.Location = new System.Drawing.Point(18, 61);
            this.Rbtn_PaulseFollow.Name = "Rbtn_PaulseFollow";
            this.Rbtn_PaulseFollow.Size = new System.Drawing.Size(172, 25);
            this.Rbtn_PaulseFollow.TabIndex = 1;
            this.Rbtn_PaulseFollow.Text = "Pulse Follow Mode";
            this.Rbtn_PaulseFollow.UseVisualStyleBackColor = true;
            // 
            // Rbtn_DC
            // 
            this.Rbtn_DC.AutoSize = true;
            this.Rbtn_DC.Location = new System.Drawing.Point(18, 30);
            this.Rbtn_DC.Name = "Rbtn_DC";
            this.Rbtn_DC.Size = new System.Drawing.Size(100, 25);
            this.Rbtn_DC.TabIndex = 0;
            this.Rbtn_DC.Text = "DC Mode";
            this.Rbtn_DC.UseVisualStyleBackColor = true;
            // 
            // TbxBrightness
            // 
            this.TbxBrightness.Location = new System.Drawing.Point(428, 36);
            this.TbxBrightness.Name = "TbxBrightness";
            this.TbxBrightness.Size = new System.Drawing.Size(52, 29);
            this.TbxBrightness.TabIndex = 41;
            this.TbxBrightness.KeyDown += new System.Windows.Forms.KeyEventHandler(this.TbxBrightness_KeyDown);
            this.TbxBrightness.Validated += new System.EventHandler(this.TbxBrightness_Validated);
            // 
            // BarBrightness
            // 
            this.BarBrightness.Location = new System.Drawing.Point(224, 36);
            this.BarBrightness.Maximum = 100;
            this.BarBrightness.Name = "BarBrightness";
            this.BarBrightness.Size = new System.Drawing.Size(198, 45);
            this.BarBrightness.TabIndex = 40;
            this.BarBrightness.Scroll += new System.EventHandler(this.BarBrightness_Scroll);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(238, 12);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(91, 21);
            this.label7.TabIndex = 39;
            this.label7.Text = "Brightness";
            // 
            // PageLight
            // 
            this.PageLight.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.PageLight.Controls.Add(this.Btn_DarkField_Send);
            this.PageLight.Controls.Add(this.Ckx_DarkField_ErrorDetect);
            this.PageLight.Controls.Add(this.Ckx_DarkField_Autosense);
            this.PageLight.Controls.Add(this.Ckx_DarkField_PosTrigger);
            this.PageLight.Controls.Add(this.Tbx_DarkField_OuputCurrent);
            this.PageLight.Controls.Add(this.Tbx_DarkField_ReTriggerDelay);
            this.PageLight.Controls.Add(this.Tbx_DarkField_TriggerDelay);
            this.PageLight.Controls.Add(this.Tbx_DarkField_PulseWidth);
            this.PageLight.Controls.Add(this.label11);
            this.PageLight.Controls.Add(this.label10);
            this.PageLight.Controls.Add(this.label9);
            this.PageLight.Controls.Add(this.label8);
            this.PageLight.Controls.Add(this.label6);
            this.PageLight.Controls.Add(this.Cbx_DarkField_Channel);
            this.PageLight.Controls.Add(this.label1);
            this.PageLight.Location = new System.Drawing.Point(4, 33);
            this.PageLight.Name = "PageLight";
            this.PageLight.Size = new System.Drawing.Size(486, 256);
            this.PageLight.TabIndex = 3;
            this.PageLight.Text = "暗場光源";
            // 
            // Btn_DarkField_Send
            // 
            this.Btn_DarkField_Send.BackColor = System.Drawing.SystemColors.Control;
            this.Btn_DarkField_Send.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.Btn_DarkField_Send.ForeColor = System.Drawing.Color.Black;
            this.Btn_DarkField_Send.Location = new System.Drawing.Point(294, 170);
            this.Btn_DarkField_Send.Name = "Btn_DarkField_Send";
            this.Btn_DarkField_Send.Size = new System.Drawing.Size(153, 70);
            this.Btn_DarkField_Send.TabIndex = 53;
            this.Btn_DarkField_Send.Text = "Send CMD";
            this.Btn_DarkField_Send.UseVisualStyleBackColor = false;
            this.Btn_DarkField_Send.Click += new System.EventHandler(this.Btn_DarkField_Send_Click);
            // 
            // Ckx_DarkField_ErrorDetect
            // 
            this.Ckx_DarkField_ErrorDetect.AutoSize = true;
            this.Ckx_DarkField_ErrorDetect.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.Ckx_DarkField_ErrorDetect.Location = new System.Drawing.Point(294, 61);
            this.Ckx_DarkField_ErrorDetect.Name = "Ckx_DarkField_ErrorDetect";
            this.Ckx_DarkField_ErrorDetect.Size = new System.Drawing.Size(120, 25);
            this.Ckx_DarkField_ErrorDetect.TabIndex = 52;
            this.Ckx_DarkField_ErrorDetect.Text = "Error Detect";
            this.Ckx_DarkField_ErrorDetect.UseVisualStyleBackColor = true;
            // 
            // Ckx_DarkField_Autosense
            // 
            this.Ckx_DarkField_Autosense.AutoSize = true;
            this.Ckx_DarkField_Autosense.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.Ckx_DarkField_Autosense.Location = new System.Drawing.Point(294, 127);
            this.Ckx_DarkField_Autosense.Name = "Ckx_DarkField_Autosense";
            this.Ckx_DarkField_Autosense.Size = new System.Drawing.Size(176, 25);
            this.Ckx_DarkField_Autosense.TabIndex = 51;
            this.Ckx_DarkField_Autosense.Text = "Autosense Enabled";
            this.Ckx_DarkField_Autosense.UseVisualStyleBackColor = true;
            // 
            // Ckx_DarkField_PosTrigger
            // 
            this.Ckx_DarkField_PosTrigger.AutoSize = true;
            this.Ckx_DarkField_PosTrigger.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.Ckx_DarkField_PosTrigger.Location = new System.Drawing.Point(294, 94);
            this.Ckx_DarkField_PosTrigger.Name = "Ckx_DarkField_PosTrigger";
            this.Ckx_DarkField_PosTrigger.Size = new System.Drawing.Size(115, 25);
            this.Ckx_DarkField_PosTrigger.TabIndex = 50;
            this.Ckx_DarkField_PosTrigger.Text = "Pos Trigger";
            this.Ckx_DarkField_PosTrigger.UseVisualStyleBackColor = true;
            // 
            // Tbx_DarkField_OuputCurrent
            // 
            this.Tbx_DarkField_OuputCurrent.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.Tbx_DarkField_OuputCurrent.Location = new System.Drawing.Point(183, 174);
            this.Tbx_DarkField_OuputCurrent.Name = "Tbx_DarkField_OuputCurrent";
            this.Tbx_DarkField_OuputCurrent.Size = new System.Drawing.Size(94, 29);
            this.Tbx_DarkField_OuputCurrent.TabIndex = 48;
            // 
            // Tbx_DarkField_ReTriggerDelay
            // 
            this.Tbx_DarkField_ReTriggerDelay.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.Tbx_DarkField_ReTriggerDelay.Location = new System.Drawing.Point(183, 211);
            this.Tbx_DarkField_ReTriggerDelay.Name = "Tbx_DarkField_ReTriggerDelay";
            this.Tbx_DarkField_ReTriggerDelay.Size = new System.Drawing.Size(94, 29);
            this.Tbx_DarkField_ReTriggerDelay.TabIndex = 47;
            // 
            // Tbx_DarkField_TriggerDelay
            // 
            this.Tbx_DarkField_TriggerDelay.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.Tbx_DarkField_TriggerDelay.Location = new System.Drawing.Point(183, 136);
            this.Tbx_DarkField_TriggerDelay.Name = "Tbx_DarkField_TriggerDelay";
            this.Tbx_DarkField_TriggerDelay.Size = new System.Drawing.Size(94, 29);
            this.Tbx_DarkField_TriggerDelay.TabIndex = 46;
            // 
            // Tbx_DarkField_PulseWidth
            // 
            this.Tbx_DarkField_PulseWidth.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.Tbx_DarkField_PulseWidth.Location = new System.Drawing.Point(183, 98);
            this.Tbx_DarkField_PulseWidth.Name = "Tbx_DarkField_PulseWidth";
            this.Tbx_DarkField_PulseWidth.Size = new System.Drawing.Size(94, 29);
            this.Tbx_DarkField_PulseWidth.TabIndex = 45;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label11.Location = new System.Drawing.Point(5, 102);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(136, 21);
            this.label11.TabIndex = 44;
            this.label11.Text = "Pulse Width (us)";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label10.Location = new System.Drawing.Point(5, 176);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(155, 21);
            this.label10.TabIndex = 43;
            this.label10.Text = "Output Current (A)";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(5, 214);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(172, 21);
            this.label9.TabIndex = 42;
            this.label9.Text = "Re-Trigger Delay (us)";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label8.Location = new System.Drawing.Point(5, 138);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(145, 21);
            this.label8.TabIndex = 41;
            this.label8.Text = "Trigger Delay (us)";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label6.Location = new System.Drawing.Point(5, 64);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(73, 21);
            this.label6.TabIndex = 40;
            this.label6.Text = "Channel";
            // 
            // Cbx_DarkField_Channel
            // 
            this.Cbx_DarkField_Channel.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.Cbx_DarkField_Channel.FormattingEnabled = true;
            this.Cbx_DarkField_Channel.Items.AddRange(new object[] {
            "0",
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7"});
            this.Cbx_DarkField_Channel.Location = new System.Drawing.Point(183, 61);
            this.Cbx_DarkField_Channel.Name = "Cbx_DarkField_Channel";
            this.Cbx_DarkField_Channel.Size = new System.Drawing.Size(94, 29);
            this.Cbx_DarkField_Channel.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label1.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label1.Location = new System.Drawing.Point(6, 10);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(171, 23);
            this.label1.TabIndex = 0;
            this.label1.Text = "Pulsed Output Mode";
            // 
            // PageRevo
            // 
            this.PageRevo.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.PageRevo.Controls.Add(this.Btn_Revo_ReadStatus);
            this.PageRevo.Controls.Add(this.Tbx_Revo_SensorStatus);
            this.PageRevo.Controls.Add(this.Tbx_Revo_Version);
            this.PageRevo.Controls.Add(this.Tbx_Revo_ConnectionStatus);
            this.PageRevo.Controls.Add(this.Tbx_Revo_Communication);
            this.PageRevo.Controls.Add(this.label16);
            this.PageRevo.Controls.Add(this.label15);
            this.PageRevo.Controls.Add(this.label14);
            this.PageRevo.Controls.Add(this.label13);
            this.PageRevo.Controls.Add(this.Tbx_Revo_OperationStatus);
            this.PageRevo.Controls.Add(this.label12);
            this.PageRevo.Controls.Add(this.Btn_Revo_Stop);
            this.PageRevo.Controls.Add(this.Btn_Revo_Move);
            this.PageRevo.Controls.Add(this.groupBox2);
            this.PageRevo.ForeColor = System.Drawing.SystemColors.Control;
            this.PageRevo.Location = new System.Drawing.Point(4, 33);
            this.PageRevo.Name = "PageRevo";
            this.PageRevo.Size = new System.Drawing.Size(486, 256);
            this.PageRevo.TabIndex = 2;
            this.PageRevo.Text = "鼻輪";
            // 
            // Btn_Revo_ReadStatus
            // 
            this.Btn_Revo_ReadStatus.BackColor = System.Drawing.SystemColors.Control;
            this.Btn_Revo_ReadStatus.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.Btn_Revo_ReadStatus.ForeColor = System.Drawing.Color.Black;
            this.Btn_Revo_ReadStatus.Location = new System.Drawing.Point(10, 105);
            this.Btn_Revo_ReadStatus.Name = "Btn_Revo_ReadStatus";
            this.Btn_Revo_ReadStatus.Size = new System.Drawing.Size(141, 39);
            this.Btn_Revo_ReadStatus.TabIndex = 66;
            this.Btn_Revo_ReadStatus.Text = "Read Status";
            this.Btn_Revo_ReadStatus.UseVisualStyleBackColor = false;
            this.Btn_Revo_ReadStatus.Click += new System.EventHandler(this.Btn_Revo_ReadStatus_Click);
            // 
            // Tbx_Revo_SensorStatus
            // 
            this.Tbx_Revo_SensorStatus.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.Tbx_Revo_SensorStatus.Location = new System.Drawing.Point(380, 168);
            this.Tbx_Revo_SensorStatus.Name = "Tbx_Revo_SensorStatus";
            this.Tbx_Revo_SensorStatus.Size = new System.Drawing.Size(94, 29);
            this.Tbx_Revo_SensorStatus.TabIndex = 65;
            // 
            // Tbx_Revo_Version
            // 
            this.Tbx_Revo_Version.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.Tbx_Revo_Version.Location = new System.Drawing.Point(380, 219);
            this.Tbx_Revo_Version.Name = "Tbx_Revo_Version";
            this.Tbx_Revo_Version.Size = new System.Drawing.Size(94, 29);
            this.Tbx_Revo_Version.TabIndex = 64;
            // 
            // Tbx_Revo_ConnectionStatus
            // 
            this.Tbx_Revo_ConnectionStatus.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.Tbx_Revo_ConnectionStatus.Location = new System.Drawing.Point(324, 111);
            this.Tbx_Revo_ConnectionStatus.Name = "Tbx_Revo_ConnectionStatus";
            this.Tbx_Revo_ConnectionStatus.Size = new System.Drawing.Size(94, 29);
            this.Tbx_Revo_ConnectionStatus.TabIndex = 63;
            // 
            // Tbx_Revo_Communication
            // 
            this.Tbx_Revo_Communication.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.Tbx_Revo_Communication.Location = new System.Drawing.Point(152, 219);
            this.Tbx_Revo_Communication.Name = "Tbx_Revo_Communication";
            this.Tbx_Revo_Communication.Size = new System.Drawing.Size(94, 29);
            this.Tbx_Revo_Communication.TabIndex = 62;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label16.Location = new System.Drawing.Point(264, 171);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(110, 21);
            this.label16.TabIndex = 61;
            this.label16.Text = "SensorStatus";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label15.Location = new System.Drawing.Point(306, 225);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(68, 21);
            this.label15.TabIndex = 60;
            this.label15.Text = "Version";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label14.Location = new System.Drawing.Point(172, 114);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(146, 21);
            this.label14.TabIndex = 59;
            this.label14.Text = "ConnectionStatus";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label13.Location = new System.Drawing.Point(14, 222);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(132, 21);
            this.label13.TabIndex = 58;
            this.label13.Text = "Communication";
            // 
            // Tbx_Revo_OperationStatus
            // 
            this.Tbx_Revo_OperationStatus.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.Tbx_Revo_OperationStatus.Location = new System.Drawing.Point(152, 168);
            this.Tbx_Revo_OperationStatus.Name = "Tbx_Revo_OperationStatus";
            this.Tbx_Revo_OperationStatus.Size = new System.Drawing.Size(94, 29);
            this.Tbx_Revo_OperationStatus.TabIndex = 57;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label12.Location = new System.Drawing.Point(11, 171);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(135, 21);
            this.label12.TabIndex = 56;
            this.label12.Text = "OperationStatus";
            // 
            // Btn_Revo_Stop
            // 
            this.Btn_Revo_Stop.BackColor = System.Drawing.SystemColors.Control;
            this.Btn_Revo_Stop.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.Btn_Revo_Stop.ForeColor = System.Drawing.Color.Black;
            this.Btn_Revo_Stop.Location = new System.Drawing.Point(310, 19);
            this.Btn_Revo_Stop.Name = "Btn_Revo_Stop";
            this.Btn_Revo_Stop.Size = new System.Drawing.Size(91, 54);
            this.Btn_Revo_Stop.TabIndex = 55;
            this.Btn_Revo_Stop.Text = "Stop";
            this.Btn_Revo_Stop.UseVisualStyleBackColor = false;
            this.Btn_Revo_Stop.Click += new System.EventHandler(this.Btn_Revo_Stop_Click);
            // 
            // Btn_Revo_Move
            // 
            this.Btn_Revo_Move.BackColor = System.Drawing.SystemColors.Control;
            this.Btn_Revo_Move.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.Btn_Revo_Move.ForeColor = System.Drawing.Color.Black;
            this.Btn_Revo_Move.Location = new System.Drawing.Point(213, 19);
            this.Btn_Revo_Move.Name = "Btn_Revo_Move";
            this.Btn_Revo_Move.Size = new System.Drawing.Size(91, 54);
            this.Btn_Revo_Move.TabIndex = 54;
            this.Btn_Revo_Move.Text = "Move";
            this.Btn_Revo_Move.UseVisualStyleBackColor = false;
            this.Btn_Revo_Move.Click += new System.EventHandler(this.Btn_Revo_Move_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.Rbtn_Revo_D);
            this.groupBox2.Controls.Add(this.Rbtn_Revo_C);
            this.groupBox2.Controls.Add(this.Rbtn_Revo_B);
            this.groupBox2.Controls.Add(this.Rbtn_Revo_A);
            this.groupBox2.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.groupBox2.ForeColor = System.Drawing.SystemColors.Control;
            this.groupBox2.Location = new System.Drawing.Point(4, 7);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(187, 66);
            this.groupBox2.TabIndex = 43;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Revo Index";
            // 
            // Rbtn_Revo_D
            // 
            this.Rbtn_Revo_D.AutoSize = true;
            this.Rbtn_Revo_D.Location = new System.Drawing.Point(141, 31);
            this.Rbtn_Revo_D.Name = "Rbtn_Revo_D";
            this.Rbtn_Revo_D.Size = new System.Drawing.Size(40, 25);
            this.Rbtn_Revo_D.TabIndex = 3;
            this.Rbtn_Revo_D.TabStop = true;
            this.Rbtn_Revo_D.Text = "D";
            this.Rbtn_Revo_D.UseVisualStyleBackColor = true;
            // 
            // Rbtn_Revo_C
            // 
            this.Rbtn_Revo_C.AutoSize = true;
            this.Rbtn_Revo_C.Location = new System.Drawing.Point(96, 31);
            this.Rbtn_Revo_C.Name = "Rbtn_Revo_C";
            this.Rbtn_Revo_C.Size = new System.Drawing.Size(39, 25);
            this.Rbtn_Revo_C.TabIndex = 2;
            this.Rbtn_Revo_C.TabStop = true;
            this.Rbtn_Revo_C.Text = "C";
            this.Rbtn_Revo_C.UseVisualStyleBackColor = true;
            // 
            // Rbtn_Revo_B
            // 
            this.Rbtn_Revo_B.AutoSize = true;
            this.Rbtn_Revo_B.Location = new System.Drawing.Point(52, 31);
            this.Rbtn_Revo_B.Name = "Rbtn_Revo_B";
            this.Rbtn_Revo_B.Size = new System.Drawing.Size(38, 25);
            this.Rbtn_Revo_B.TabIndex = 1;
            this.Rbtn_Revo_B.TabStop = true;
            this.Rbtn_Revo_B.Text = "B";
            this.Rbtn_Revo_B.UseVisualStyleBackColor = true;
            // 
            // Rbtn_Revo_A
            // 
            this.Rbtn_Revo_A.AutoSize = true;
            this.Rbtn_Revo_A.Location = new System.Drawing.Point(6, 31);
            this.Rbtn_Revo_A.Name = "Rbtn_Revo_A";
            this.Rbtn_Revo_A.Size = new System.Drawing.Size(40, 25);
            this.Rbtn_Revo_A.TabIndex = 0;
            this.Rbtn_Revo_A.TabStop = true;
            this.Rbtn_Revo_A.Text = "A";
            this.Rbtn_Revo_A.UseVisualStyleBackColor = true;
            // 
            // PageConfig
            // 
            this.PageConfig.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.PageConfig.Controls.Add(this.PGrid_Config);
            this.PageConfig.Location = new System.Drawing.Point(4, 33);
            this.PageConfig.Name = "PageConfig";
            this.PageConfig.Padding = new System.Windows.Forms.Padding(3);
            this.PageConfig.Size = new System.Drawing.Size(486, 256);
            this.PageConfig.TabIndex = 4;
            this.PageConfig.Text = "參數設定";
            // 
            // PGrid_Config
            // 
            this.PGrid_Config.ContextMenuStrip = this.contextMenuStrip1;
            this.PGrid_Config.Dock = System.Windows.Forms.DockStyle.Fill;
            this.PGrid_Config.Location = new System.Drawing.Point(3, 3);
            this.PGrid_Config.Name = "PGrid_Config";
            this.PGrid_Config.Size = new System.Drawing.Size(480, 250);
            this.PGrid_Config.TabIndex = 0;
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.BtnSaveConfig});
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(201, 34);
            // 
            // BtnSaveConfig
            // 
            this.BtnSaveConfig.BackColor = System.Drawing.Color.Yellow;
            this.BtnSaveConfig.Font = new System.Drawing.Font("微軟正黑體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.BtnSaveConfig.ForeColor = System.Drawing.Color.Blue;
            this.BtnSaveConfig.Name = "BtnSaveConfig";
            this.BtnSaveConfig.Size = new System.Drawing.Size(200, 30);
            this.BtnSaveConfig.Text = "Save Config";
            this.BtnSaveConfig.Click += new System.EventHandler(this.BtnSaveConfig_Click);
            // 
            // PageVersion
            // 
            this.PageVersion.Controls.Add(this.RTbxVersion);
            this.PageVersion.Location = new System.Drawing.Point(4, 33);
            this.PageVersion.Name = "PageVersion";
            this.PageVersion.Size = new System.Drawing.Size(486, 256);
            this.PageVersion.TabIndex = 5;
            this.PageVersion.Text = "版本";
            this.PageVersion.UseVisualStyleBackColor = true;
            // 
            // RTbxVersion
            // 
            this.RTbxVersion.Dock = System.Windows.Forms.DockStyle.Fill;
            this.RTbxVersion.Location = new System.Drawing.Point(0, 0);
            this.RTbxVersion.Name = "RTbxVersion";
            this.RTbxVersion.Size = new System.Drawing.Size(486, 256);
            this.RTbxVersion.TabIndex = 0;
            this.RTbxVersion.Text = "Ver. 2024/03/05\n1. WDI LED 新增 Pulse Trigger Mode\n\nVer. 2024/02/02\n1. 放寬WDI AF MOV" +
    "E容許值 (<1um)\n\nVer. 2024/02/01\n1. 新增BackupData，紀錄最後使用參數 (手動)\n\nVer. 2024/01/30\n1. W" +
    "DI AF Move 新增 位置判斷\n2. WDI Init 即 Home \n";
            // 
            // RichTbx_Log_Main
            // 
            this.RichTbx_Log_Main.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.RichTbx_Log_Main.Font = new System.Drawing.Font("微軟正黑體", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.RichTbx_Log_Main.Location = new System.Drawing.Point(4, 54);
            this.RichTbx_Log_Main.Margin = new System.Windows.Forms.Padding(1);
            this.RichTbx_Log_Main.Name = "RichTbx_Log_Main";
            this.RichTbx_Log_Main.ReadOnly = true;
            this.RichTbx_Log_Main.Size = new System.Drawing.Size(494, 218);
            this.RichTbx_Log_Main.TabIndex = 26;
            this.RichTbx_Log_Main.Text = "";
            // 
            // BtnZoom
            // 
            this.BtnZoom.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.BtnZoom.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.BtnZoom.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.BtnZoom.Location = new System.Drawing.Point(419, 4);
            this.BtnZoom.Name = "BtnZoom";
            this.BtnZoom.Size = new System.Drawing.Size(79, 46);
            this.BtnZoom.TabIndex = 28;
            this.BtnZoom.Text = "▲ ▲ ▲";
            this.BtnZoom.UseVisualStyleBackColor = false;
            this.BtnZoom.Click += new System.EventHandler(this.BtnZoom_Click);
            // 
            // LabelAF
            // 
            this.LabelAF.BackColor = System.Drawing.Color.Silver;
            this.LabelAF.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.LabelAF.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.LabelAF.Location = new System.Drawing.Point(123, 4);
            this.LabelAF.Name = "LabelAF";
            this.LabelAF.Size = new System.Drawing.Size(68, 45);
            this.LabelAF.TabIndex = 30;
            this.LabelAF.Text = "對焦";
            this.LabelAF.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.LabelAF.DoubleClick += new System.EventHandler(this.LabelAF_DoubleClick);
            // 
            // LabelLED
            // 
            this.LabelLED.BackColor = System.Drawing.Color.Silver;
            this.LabelLED.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.LabelLED.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.LabelLED.Location = new System.Drawing.Point(197, 4);
            this.LabelLED.Name = "LabelLED";
            this.LabelLED.Size = new System.Drawing.Size(68, 45);
            this.LabelLED.TabIndex = 31;
            this.LabelLED.Text = "LED";
            this.LabelLED.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.LabelLED.DoubleClick += new System.EventHandler(this.LabelLED_DoubleClick);
            // 
            // LabelDarkField
            // 
            this.LabelDarkField.BackColor = System.Drawing.Color.Silver;
            this.LabelDarkField.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.LabelDarkField.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.LabelDarkField.Location = new System.Drawing.Point(271, 4);
            this.LabelDarkField.Name = "LabelDarkField";
            this.LabelDarkField.Size = new System.Drawing.Size(68, 45);
            this.LabelDarkField.TabIndex = 32;
            this.LabelDarkField.Text = "暗場";
            this.LabelDarkField.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.LabelDarkField.DoubleClick += new System.EventHandler(this.LabelDarkField_DoubleClick);
            // 
            // LabelRevo
            // 
            this.LabelRevo.BackColor = System.Drawing.Color.Silver;
            this.LabelRevo.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.LabelRevo.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.LabelRevo.Location = new System.Drawing.Point(345, 4);
            this.LabelRevo.Name = "LabelRevo";
            this.LabelRevo.Size = new System.Drawing.Size(68, 45);
            this.LabelRevo.TabIndex = 33;
            this.LabelRevo.Text = "鼻輪";
            this.LabelRevo.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.LabelRevo.DoubleClick += new System.EventHandler(this.LabelRevo_DoubleClick);
            // 
            // LabelSvr
            // 
            this.LabelSvr.BackColor = System.Drawing.Color.Gray;
            this.LabelSvr.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.LabelSvr.Font = new System.Drawing.Font("微軟正黑體", 27.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.LabelSvr.ForeColor = System.Drawing.Color.White;
            this.LabelSvr.Location = new System.Drawing.Point(4, 4);
            this.LabelSvr.Name = "LabelSvr";
            this.LabelSvr.Size = new System.Drawing.Size(113, 45);
            this.LabelSvr.TabIndex = 34;
            this.LabelSvr.Text = "1";
            this.LabelSvr.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.LabelSvr.DoubleClick += new System.EventHandler(this.LabelSvr_DoubleClick);
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 24F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.ClientSize = new System.Drawing.Size(503, 574);
            this.Controls.Add(this.LabelSvr);
            this.Controls.Add(this.LabelRevo);
            this.Controls.Add(this.LabelDarkField);
            this.Controls.Add(this.LabelLED);
            this.Controls.Add(this.LabelAF);
            this.Controls.Add(this.BtnZoom);
            this.Controls.Add(this.RichTbx_Log_Main);
            this.Controls.Add(this.TabCtrl);
            this.Font = new System.Drawing.Font("微軟正黑體", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.ForeColor = System.Drawing.SystemColors.Control;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.Margin = new System.Windows.Forms.Padding(6);
            this.MaximizeBox = false;
            this.Name = "MainForm";
            this.Text = "OpticalControl";
            this.Load += new System.EventHandler(this.MainForm_Load);
            this.SizeChanged += new System.EventHandler(this.MainForm_SizeChanged);
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.TabCtrl.ResumeLayout(false);
            this.PageWDI.ResumeLayout(false);
            this.PageWDI.PerformLayout();
            this.PageWDILED.ResumeLayout(false);
            this.PageWDILED.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.BarBrightness)).EndInit();
            this.PageLight.ResumeLayout(false);
            this.PageLight.PerformLayout();
            this.PageRevo.ResumeLayout(false);
            this.PageRevo.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.PageConfig.ResumeLayout(false);
            this.contextMenuStrip1.ResumeLayout(false);
            this.PageVersion.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.TextBox TbxWdiDefZ;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button BtnAFMove;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.Button BtnWdiGetSubStrate;
        private System.Windows.Forms.TextBox TbxWdiSubstrate;
        private System.Windows.Forms.ComboBox Cbx_WdiSubStrate;
        private System.Windows.Forms.Button BtnWdiSetSubStrate;
        private System.Windows.Forms.Button BtnWdiOff;
        private System.Windows.Forms.TextBox TbxWdiLimitU;
        private System.Windows.Forms.Button BtnWdiHome;
        private System.Windows.Forms.TextBox TbxWdiLimitL;
        private System.Windows.Forms.Button BtnWdiRead;
        private System.Windows.Forms.Button BtnWdiOn;
        private System.Windows.Forms.TextBox TbxWdiPos;
        private System.Windows.Forms.TabControl TabCtrl;
        private System.Windows.Forms.TabPage PageWDI;
        private System.Windows.Forms.TabPage PageWDILED;
        private System.Windows.Forms.Button BtnLEDSendCMD;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.RadioButton Rbtn_Off;
        private System.Windows.Forms.RadioButton Rbtn_PaulseFollow;
        private System.Windows.Forms.RadioButton Rbtn_DC;
        private System.Windows.Forms.TextBox TbxBrightness;
        private System.Windows.Forms.TrackBar BarBrightness;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TabPage PageRevo;
        private System.Windows.Forms.RichTextBox RichTbx_Log_Main;
        private System.Windows.Forms.Button BtnZoom;
        private System.Windows.Forms.TabPage PageLight;
        private System.Windows.Forms.Label LabelAF;
        private System.Windows.Forms.Label LabelLED;
        private System.Windows.Forms.Label LabelDarkField;
        private System.Windows.Forms.Label LabelRevo;
        private System.Windows.Forms.Label LabelSvr;
        private System.Windows.Forms.TabPage PageConfig;
        private System.Windows.Forms.PropertyGrid PGrid_Config;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.ToolStripMenuItem BtnSaveConfig;
        private System.Windows.Forms.Button Btn_DarkField_Send;
        private System.Windows.Forms.CheckBox Ckx_DarkField_ErrorDetect;
        private System.Windows.Forms.CheckBox Ckx_DarkField_Autosense;
        private System.Windows.Forms.CheckBox Ckx_DarkField_PosTrigger;
        private System.Windows.Forms.TextBox Tbx_DarkField_OuputCurrent;
        private System.Windows.Forms.TextBox Tbx_DarkField_ReTriggerDelay;
        private System.Windows.Forms.TextBox Tbx_DarkField_TriggerDelay;
        private System.Windows.Forms.TextBox Tbx_DarkField_PulseWidth;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.ComboBox Cbx_DarkField_Channel;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox Tbx_Revo_OperationStatus;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Button Btn_Revo_Stop;
        private System.Windows.Forms.Button Btn_Revo_Move;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.RadioButton Rbtn_Revo_D;
        private System.Windows.Forms.RadioButton Rbtn_Revo_C;
        private System.Windows.Forms.RadioButton Rbtn_Revo_B;
        private System.Windows.Forms.RadioButton Rbtn_Revo_A;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Button Btn_Revo_ReadStatus;
        private System.Windows.Forms.TextBox Tbx_Revo_SensorStatus;
        private System.Windows.Forms.TextBox Tbx_Revo_Version;
        private System.Windows.Forms.TextBox Tbx_Revo_ConnectionStatus;
        private System.Windows.Forms.TextBox Tbx_Revo_Communication;
        private System.Windows.Forms.Button Btn_WDIAF_SetLED;
        private System.Windows.Forms.TextBox Tbx_WDIAF_Channel;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.TextBox Tbx_WDIAF_uPWM;
        private System.Windows.Forms.TextBox Tbx_WDIAF_Current;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.TabPage PageVersion;
        private System.Windows.Forms.RichTextBox RTbxVersion;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.RadioButton Rbtn_PaulseTrigger;
        private System.Windows.Forms.TextBox TbxDuration;
        private System.Windows.Forms.TextBox TbxTriggerDelay;
    }
}

