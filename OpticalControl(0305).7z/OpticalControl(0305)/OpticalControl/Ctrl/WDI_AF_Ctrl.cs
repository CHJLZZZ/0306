﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Security;
using System.Text;
using System.Threading.Tasks;
using Microsoft.VisualBasic;
using System.Threading;

public class WDI_AF_Ctrl
{
    public static event Action<string, bool> WriteLog;
    public static event Action<bool> IsConnectEvent;

    private string DeviceName = "";
    private int Comport = -1;
    private int DeviceIdx = -1;

    public static bool _LaserOn;
    public static bool _StartAF;
    public static double Res = 0.15625; // 1pulse=0.15um

    public static void SaveLog(string LogStr, bool isAlm = false)
    {
        WriteLog?.Invoke(LogStr, isAlm);
    }

    #region 單動

    public static WdiRtn ConnectPort(int comport)
    {
        WdiRtn rtn = new WdiRtn();

        try
        {
            WDI.ATF.ATF_CloseConnection();

            int i = WDI.ATF.ATF_OpenConnection($@"\\.\COM{comport}", 9600);

            if (i != 0)
            {
                rtn.ErrorOccure = true;
                rtn.ErrorString = $"Connect Fail , Com{comport} , ErrorCode = {i}";
                SaveLog(rtn.ErrorString, true);
                IsConnectEvent?.Invoke(false);
            }
            else
            {
                rtn.ErrorOccure = false;
                rtn.ErrorString = "";

                SaveLog($"Connect Success !!");
                IsConnectEvent?.Invoke(true);
            }
        }
        catch (Exception ex)
        {
            rtn.ErrorOccure = true;
            rtn.ErrorString = $"Connect Fail , Com{comport} , Error = {ex.Message}";
            SaveLog(rtn.ErrorString, true);
            IsConnectEvent?.Invoke(false);
        }

        return rtn;
    }

    public static int GetComIdx()
    {
        int ComIdx = -1;
        ComIdx = WDI.ATF.ATF_GetComIdx();
        return ComIdx;
    }

    public static WdiRtn SetComIdx(int Idx)
    {
        WdiRtn rtn = new WdiRtn();

        try
        {
            int i = WDI.ATF.ATF_SetComIdx(Idx);
            if (i != 0)
            {
                rtn.ErrorOccure = true;
                rtn.ErrorString = $"WDI Set ComIdx Fail : {Idx} , ErrorCode = {i}";
                SaveLog(rtn.ErrorString, true);
            }
            else
            {
                rtn.ErrorOccure = false;
                rtn.ErrorString = "";
                SaveLog($"WDI Set ComIdx : {Idx}");
            }
        }
        catch (Exception ex)
        {
            rtn.ErrorOccure = true;
            rtn.ErrorString = $"WDI Set ComIdx Fail : {Idx} , Error = {ex.Message}";
            SaveLog(rtn.ErrorString, true);
        }

        return rtn;
    }

    public static WdiRtn Read_Pos(ref double pos)
    {
        WdiRtn rtn = new WdiRtn();
        int pulse;

        try
        {
            int i = WDI.ATF.ATF_ReadAbsZPos(out pulse);
            pos = pulse * Res; // unit:um

            if (i != 0)
            {
                rtn.ErrorOccure = true;
                rtn.ErrorString = $"Read Pos Fail , ErrorCode = {i}";
                SaveLog(rtn.ErrorString, true);
            }
            else
            {
                rtn.ErrorOccure = false;
                rtn.ErrorString = "";
                SaveLog($"Read Pos : {pos} um");
            }
        }
        catch (Exception ex)
        {
            rtn.ErrorOccure = true;
            rtn.ErrorString = $"Read Pos Fail , Error = {ex.Message}";
            SaveLog(rtn.ErrorString, true);
        }

        return rtn;
    }

    public static WdiRtn ATF_Reset()
    {
        WdiRtn rtn = new WdiRtn();

        try
        {
            int i = WDI.ATF.ATF_Reset();

            if (i != 0)
            {
                rtn.ErrorOccure = true;
                rtn.ErrorString = $"ATF Reset Fail , ErrorCode = {i}";
                SaveLog(rtn.ErrorString, true);
            }
            else
            {
                rtn.ErrorOccure = false;
                rtn.ErrorString = "";
                SaveLog($"ATF Reset");
            }
        }
        catch (Exception ex)
        {
            rtn.ErrorOccure = true;
            rtn.ErrorString = $"ATF Reset Fail , Error = {ex.Message}";
            SaveLog(rtn.ErrorString, true);
        }

        return rtn;
    }

    public static WdiRtn Home()
    {
        WdiRtn rtn = new WdiRtn();
        try
        {
            int i = WDI.ATF.ATF_RunHomingZ_CurrentParams_cs();

            if (i != 0)
            {
                rtn.ErrorOccure = true;
                rtn.ErrorString = $"Home Fail , ErrorCode = {i}";
                SaveLog(rtn.ErrorString, true);
            }
            else
            {
                rtn.ErrorOccure = false;
                rtn.ErrorString = "";
                rtn.ErrorString = $"Homed";
            }
        }
        catch (Exception ex)
        {
            rtn.ErrorOccure = true;
            rtn.ErrorString = $"Home Fail , Error = {ex.Message}";
            SaveLog(rtn.ErrorString, true);
        }

        return rtn;
    }

    public static WdiRtn Move(AFzMoveType type, double TargetPos)
    {
        WdiRtn rtn = new WdiRtn();

        try
        {
            double NowPos = 0;
            Read_Pos(ref NowPos);

            double OffsetPos;

            switch (type)
            {
                case AFzMoveType.ABS:
                    {
                        OffsetPos = TargetPos - NowPos;
                        if (Math.Abs(TargetPos) > 8000)
                        {
                            rtn.ErrorOccure = true;
                            rtn.ErrorString = "Move Error , Over Range: -4mm ~ 4mm ";
                            SaveLog(rtn.ErrorString, true);
                        }
                        else
                        {
                            rtn = MoveZ(OffsetPos);

                            if (!rtn.ErrorOccure) SaveLog($"ATF Move Z To {TargetPos} um");
                        }


                        break;
                    }

                case AFzMoveType.REL:
                    {
                        OffsetPos = TargetPos + NowPos;
                        if (Math.Abs(OffsetPos) > 8000)
                        {
                            rtn.ErrorOccure = true;
                            rtn.ErrorString = "Move Error , Over Range: -4mm ~ 4mm ";
                            SaveLog(rtn.ErrorString, true);
                        }
                        else
                        {
                            rtn = MoveZ(TargetPos);

                            if (!rtn.ErrorOccure) SaveLog($"ATF Move Z To {TargetPos} um");
                        }

                        break;
                    }
            }

            TimeManager TM = new TimeManager();
            TM.SetDelay(5000);

            while (Math.Abs(TargetPos - NowPos) > 1)
            {
                Read_Pos(ref NowPos);

                if (TM.IsTimeOut())
                {
                    rtn.ErrorOccure = false;
                    return rtn;
                }
            }

            return rtn;

        }
        catch (Exception ex)
        {
            rtn.ErrorOccure = true;
            rtn.ErrorString = ex.ToString();

            return rtn;

            SaveLog(rtn.ErrorString, true);
        }

    }

    public static WdiRtn MoveZ(double TargetPos)
    {
        WdiRtn rtn = new WdiRtn();
        var pulse = TargetPos / Res; // unit:pulse

        try
        {
            int i = WDI.ATF.ATF_MoveZ((int)pulse);

            if (i != 0)
            {
                rtn.ErrorOccure = true;
                rtn.ErrorString = $"ATF Move Fail , ErrorCode = {i}";
                SaveLog(rtn.ErrorString, true);
            }
            else
            {
                rtn.ErrorOccure = false;
                rtn.ErrorString = "";

            }
        }
        catch (Exception ex)
        {
            rtn.ErrorOccure = true;
            rtn.ErrorString = $"ATF Move Fail , Error = {ex.Message}";
            SaveLog(rtn.ErrorString, true);
        }

        return rtn;
    }

    public static WdiRtn Laser_On()
    {
        WdiRtn rtn = new WdiRtn();

        try
        {
            int i = WDI.ATF.ATF_EnableLaser();
            if (i != 0)
            {
                rtn.ErrorOccure = true;
                rtn.ErrorString = $"Laser On Fail , ErrorCode = {i}";
                SaveLog(rtn.ErrorString, true);
            }
            else
            {
                rtn.ErrorOccure = false;
                rtn.ErrorString = "";
                _LaserOn = true;
                SaveLog($"Laser On");
            }
        }
        catch (Exception ex)
        {
            rtn.ErrorOccure = true;
            rtn.ErrorString = $"Laser On Fail , Error = {ex.Message}";
            SaveLog(rtn.ErrorString, true);
        }

        return rtn;
    }

    public static WdiRtn Laser_Off()
    {
        WdiRtn rtn = new WdiRtn();

        try
        {
            if (!_LaserOn)
            {
                rtn.ErrorOccure = false;
                rtn.ErrorString = "";
                return rtn;
            }

            int i = WDI.ATF.ATF_DisableLaser();
            if (i != 0)
            {
                rtn.ErrorOccure = true;
                rtn.ErrorString = $"Laser Off Fail , ErrorCode = {i}";
                SaveLog(rtn.ErrorString, true);
            }
            else
            {
                rtn.ErrorOccure = false;
                rtn.ErrorString = "";
                _LaserOn = false;
                SaveLog("Laser Off");
            }
        }
        catch (Exception ex)
        {
            rtn.ErrorOccure = true;
            rtn.ErrorString = $"Laser Off Fail , Error = {ex.Message}";
            SaveLog(rtn.ErrorString, true);
        }

        return rtn;
    }

    public static WdiRtn Start_Focus()
    {
        WdiRtn rtn = new WdiRtn();

        try
        {
            int i = WDI.ATF.ATF_AFTrack();
            if (i != 0)
            {
                rtn.ErrorOccure = true;
                rtn.ErrorString = $"AF Start Fail , ErrorCode = {i}";
                SaveLog(rtn.ErrorString, true);
            }
            else
            {
                rtn.ErrorOccure = false;
                rtn.ErrorString = "";
                _StartAF = true;
                SaveLog("AF Start");
            }
        }
        catch (Exception ex)
        {
            rtn.ErrorOccure = true;
            rtn.ErrorString = $"AF Start Fail , Error = {ex.Message}";
            SaveLog(rtn.ErrorString, true);
        }

        return rtn;
    }

    public static WdiRtn Stop_Focus()
    {
        WdiRtn rtn = new WdiRtn();
        try
        {
            if (!_StartAF)
            {
                rtn.ErrorOccure = false;
                rtn.ErrorString = "";
                return rtn;
            }

            int i = WDI.ATF.ATF_AfStop();
            if (i != 0)
            {
                rtn.ErrorOccure = true;
                rtn.ErrorString = $"AF Stop Fail , ErrorCode = {i}";
                SaveLog(rtn.ErrorString, true);
            }
            else
            {
                rtn.ErrorOccure = false;
                rtn.ErrorString = "";
                _StartAF = false;
                SaveLog("AF Stop");
            }
        }
        catch (Exception ex)
        {
            rtn.ErrorOccure = true;
            rtn.ErrorString = $"AF Stop Fail , Error = {ex.Message}";
            SaveLog(rtn.ErrorString, true);
        }

        return rtn;
    }

    public static WdiRtn Open_Limit(int iUpperPos, int iLowerPos)
    {
        WdiRtn rtn = new WdiRtn();
        var UpperPulse = iUpperPos / Res; // unit:pulse
        var LowerPulse = iLowerPos / Res; // unit:pulse

        try
        {
            int i = WDI.ATF.ATF_WriteMotionLimits((int)UpperPulse, (int)LowerPulse, 1); // 3205, -3205

            if (i != 0)
            {
                rtn.ErrorOccure = true;
                rtn.ErrorString = $"Open Limit Fail , ErrorCode = {i}";
                SaveLog(rtn.ErrorString, true);
            }
            else
            {
                rtn.ErrorOccure = false;
                rtn.ErrorString = "";
                SaveLog($"Open Limit : {iUpperPos} ~ {iLowerPos}");
            }
        }
        catch (Exception ex)
        {
            rtn.ErrorOccure = true;
            rtn.ErrorString = $"Open Limit Fail , Error = {ex.Message}";
            SaveLog(rtn.ErrorString, true);
        }

        return rtn;
    }

    public static WdiRtn Close_Limit()
    {
        WdiRtn rtn = new WdiRtn();

        try
        {
            int i = WDI.ATF.ATF_WriteMotionLimits(50000, -50000, 0);
            if (i != 0)
            {
                rtn.ErrorOccure = true;
                rtn.ErrorString = $"Close Limit Fail , ErrorCode = {i}";
                SaveLog(rtn.ErrorString, true);
            }
            else
            {
                rtn.ErrorOccure = false;
                rtn.ErrorString = "";
                SaveLog("Close Limit");
            }
        }
        catch (Exception ex)
        {
            rtn.ErrorOccure = true;
            rtn.ErrorString = $"Close Limit Fail , Error = {ex.Message}";
            SaveLog(rtn.ErrorString, true);
        }

        return rtn;
    }

    public static WdiRtn SetSubStrate(short Idx)
    {
        WdiRtn rtn = new WdiRtn();

        try
        {
            int i = WDI.ATF.ATF_WriteSurface(Idx);
            if (i != 0)
            {
                rtn.ErrorOccure = true;
                rtn.ErrorString = $"Set SubStrate Fail , ErrorCode = {i}";
                SaveLog(rtn.ErrorString, true);
            }
            else
            {
                rtn.ErrorOccure = false;
                rtn.ErrorString = "";

                string[] SubStrateName = { "A", "B", "C", "D", "E" };
                SaveLog($"Set SubStrate : {SubStrateName[Idx]}");
            }
        }
        catch (Exception ex)
        {
            rtn.ErrorOccure = true;
            rtn.ErrorString = $"Set SubStrate Fail , Error = {ex.Message}";
            SaveLog(rtn.ErrorString, true);
        }

        return rtn;
    }

    public static WdiRtn GetSubStrate(ref short Idx)
    {
        WdiRtn rtn = new WdiRtn();

        try
        {
            int i = WDI.ATF.ATF_ReadSurface(out Idx);

            if (i != 0)
            {
                rtn.ErrorOccure = true;
                rtn.ErrorString = $"Get SubStrate Fail , ErrorCode = {i}";
                SaveLog(rtn.ErrorString, true);
            }
            else
            {
                rtn.ErrorOccure = false;
                rtn.ErrorString = "";
                string[] SubStrateName = { "A", "B", "C", "D", "E" };
                SaveLog($"Get SubStrate : {SubStrateName[Idx]}");
            }
        }
        catch (Exception ex)
        {
            rtn.ErrorOccure = true;
            rtn.ErrorString = $"Get SubStrate Fail , Error = {ex.Message}";
            SaveLog(rtn.ErrorString, true);
        }

        return rtn;
    }

    public static WdiRtn Set_PositionZore()
    {
        WdiRtn rtn = new WdiRtn();
        try
        {
            int i = WDI.ATF.ATF_WriteAbsZPos(0);
            if (i != 0)
            {
                rtn.ErrorOccure = true;
                rtn.ErrorString = $"Set Pos Zero Fail , ErrorCode = {i}";
                SaveLog(rtn.ErrorString, true);
            }
            else
            {
                rtn.ErrorOccure = false;
                rtn.ErrorString = "";
                SaveLog("Set Position Zero");
            }
        }
        catch (Exception ex)
        {
            rtn.ErrorOccure = true;
            rtn.ErrorString = $"Set Pos Zero Fail , Error = {ex.Message}";
            SaveLog(rtn.ErrorString, true);
        }

        return rtn;
    }

    public static WdiRtn Set_Led(Int16 channel, ushort Current, ushort uPWM)
    {
        WdiRtn rtn = new WdiRtn();
        try
        {
            int i = 0;

            i = WDI.ATF.ATF_WriteLedCurrent(channel, Current);

            if (i != 0)
            {
                rtn.ErrorOccure = true;
                rtn.ErrorString = $"Set Led Current Fail , ErrorCode = {i}";
                SaveLog(rtn.ErrorString, true);

            }
            else
            {
                i = WDI.ATF.ATF_WriteLedPwm(channel, uPWM);

                if (i != 0)
                {
                    rtn.ErrorOccure = true;
                    rtn.ErrorString = $"Set Led Pwm Fail , ErrorCode = {i}";
                    SaveLog(rtn.ErrorString, true);

                }
                else
                {
                    rtn.ErrorOccure = false;
                    rtn.ErrorString = "";
                    SaveLog($"Set Led , Current : {Current} , Pwm : {uPWM}");
                }
            }
        }
        catch (Exception ex)
        {
            rtn.ErrorOccure = true;
            rtn.ErrorString = $"WDI Set Led Fail , Error = {ex.Message}";
            SaveLog(rtn.ErrorString, true);
        }

        return rtn;
    }

    #endregion

    public static WdiRtn WdiOn(int WDI_AbsZ, int WDI_MotorMovDelay, int WDI_ZposLimit_Upper, int WDI_ZposLimit_Lower)
    {
        WdiRtn rtnWdi = new WdiRtn();

        try
        {
            rtnWdi = Stop_Focus();
            //Thread.Sleep(100);
            if (rtnWdi.ErrorOccure)
            {
                throw new Exception(rtnWdi.ErrorString);
            }

            rtnWdi = Close_Limit();
            //Thread.Sleep(100);
            if (rtnWdi.ErrorOccure)
            {
                throw new Exception(rtnWdi.ErrorString);
            }

            rtnWdi = Move(AFzMoveType.ABS, WDI_AbsZ);
            Thread.Sleep(WDI_MotorMovDelay);
            if (rtnWdi.ErrorOccure)
            {
                throw new Exception(rtnWdi.ErrorString);
            }

            rtnWdi = Laser_On();
            //Thread.Sleep(100);
            if (rtnWdi.ErrorOccure)
            {
                throw new Exception(rtnWdi.ErrorString);
            }

            rtnWdi = Open_Limit(WDI_ZposLimit_Upper, WDI_ZposLimit_Lower);
            //Thread.Sleep(100);
            if (rtnWdi.ErrorOccure)
            {
                throw new Exception(rtnWdi.ErrorString);
            }

            rtnWdi = Start_Focus();
            //Thread.Sleep(1000);
            if (rtnWdi.ErrorOccure)
            {
                throw new Exception(rtnWdi.ErrorString);
            }
        }
        catch (Exception ex)
        {
            //SaveLog($"{ex.Message}", true);
        }

        return rtnWdi;
    }

    public static WdiRtn WdiOff(bool GoHome = false)
    {
        WdiRtn rtnWdi = new WdiRtn();

        try
        {
            rtnWdi = Stop_Focus();
            //Thread.Sleep(100);
            if (rtnWdi.ErrorOccure)
            {
                throw new Exception(rtnWdi.ErrorString);
            }

            rtnWdi = Close_Limit();
            //Thread.Sleep(100);
            if (rtnWdi.ErrorOccure)
            {
                throw new Exception(rtnWdi.ErrorString);
            }

            rtnWdi = Laser_Off();
            //Thread.Sleep(100);
            if (rtnWdi.ErrorOccure)
            {
                throw new Exception(rtnWdi.ErrorString);
            }

            if ((GoHome))
            {
                rtnWdi = ATF_Reset();
                //Thread.Sleep(100);
                if (rtnWdi.ErrorOccure)
                {
                    throw new Exception(rtnWdi.ErrorString);
                }

                rtnWdi = Home();
                //Thread.Sleep(100);
                if (rtnWdi.ErrorOccure)
                {
                    throw new Exception(rtnWdi.ErrorString);
                }

                rtnWdi = Set_PositionZore();
                Thread.Sleep(100);
                if (rtnWdi.ErrorOccure == true)
                {
                    throw new Exception(rtnWdi.ErrorString);
                }

                TimeManager TM = new TimeManager();
                TM.SetDelay(15000);
                double Pos = -1000;

                while (Pos != 0)
                {
                    Thread.Sleep(1000);
                    Read_Pos(ref Pos);

                    if (TM.IsTimeOut())
                    {
                        rtnWdi.ErrorOccure = true;
                        return rtnWdi;
                    }
                }
            }

            return rtnWdi;

        }
        catch (Exception ex)
        {
            rtnWdi.ErrorString = ex.Message;
            rtnWdi.ErrorOccure = true;
            return rtnWdi;
            //SaveLog(ex.Message, true);
        }

    }
}
public class WdiRtn
{
    public bool ErrorOccure; // 指示是否發生錯誤
    public string ErrorString; // 錯誤描述

    public WdiRtn()
    {
        this.ErrorOccure = false;
        this.ErrorString = "";
    }
}

public enum AFzMoveType
{
    ABS,
    REL
}


