﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using static WDI_AF_Ctrl;

namespace OpticalControl
{
    public partial class MainForm : Form
    {
        private System.Windows.Forms.NotifyIcon _NotifyIcon;
        private CommonBase.Logger.InfoManager Log;

        const int MaxHeight = 617;
        const int MinHeight = 97;
        const string MinStr = "▼ ▼ ▼";
        const string MaxStr = "▲ ▲ ▲";

        private string DeviceName = string.Empty;
        private string BaseFolder = string.Empty;
        private string ConfigPath = string.Empty;
        private string BackupDataPath = string.Empty;


        private SystemData SD = new SystemData();
        private BackupData BD = new BackupData();


        private WDI_Led_Ctrl WDI_LED;
        private Gardasoft_Light_Ctrl Dark_Field;
        private Revo_Ctrl Revo;


        public MainForm()
        {
            InitializeComponent();
            this.components = new System.ComponentModel.Container();

            this.FormClosing -= MainForm_FormClosing;
            this.FormClosing += MainForm_FormClosing;
        }

        private void MainForm_Load(object sender, EventArgs e)
        {
            DeviceName = System.Diagnostics.Process.GetCurrentProcess().ProcessName;
            LabelSvr.Text = DeviceName;
            BaseFolder = $@"D:\G4.5 Controller\Optical Control\{DeviceName}";
            this.Text += $" - {DeviceName}";
            if (!Directory.Exists(BaseFolder))
            {
                Directory.CreateDirectory(BaseFolder);
            }

            string LogFolder_Ganeral = $@"{BaseFolder}\Log\Ganeral";
            string LogFolder_Error = $@"{BaseFolder}\Log\Error";
            string LogFolder_Other = $@"{BaseFolder}\Log\Other";

            Log = new CommonBase.Logger.InfoManager(LogFolder_Ganeral, LogFolder_Other, LogFolder_Other, LogFolder_Error, LogFolder_Other);
            Log.SetGeneralTextBox(ref RichTbx_Log_Main);

            this.Height = MinHeight;
            BtnZoom.Text = MinStr;
            Set_NotifyIcon();

            LoadConfig();
            LoadBackupData();

            new Thread(() =>
            {
                WDI_AF_Init();
                WDI_LED_Init();
                Dark_Field_Init();
                Revo_Init();
                Svr_Init();
            }).Start();
        }

        private void LoadConfig()
        {
            string ConfigFolder = $@"{BaseFolder}\Config";
            if (!Directory.Exists(ConfigFolder))
            {
                Directory.CreateDirectory(ConfigFolder);
            }

            ConfigPath = $@"{ConfigFolder}\SystemData.xml";

            if (File.Exists(ConfigPath))
            {
                SD = SD.Read(ConfigPath);
            }
            else
            {
                SD.Create(SD, ConfigPath);
            }
            PGrid_Config.SelectedObject = SD;

        }

        private void LoadBackupData()
        {
            string ConfigFolder = $@"{BaseFolder}\Config";

            BackupDataPath = $@"{ConfigFolder}\BackupData.xml";
            if (File.Exists(BackupDataPath))
            {
                BD = BD.Read(BackupDataPath);
            }
            else
            {
                BD.Create(BD, BackupDataPath);
            }

            //WDI AF
            TbxWdiDefZ.Text = BD.WDI_AF_ZPos.ToString();
            TbxWdiLimitU.Text = BD.WDI_AF_LimitUpper.ToString();
            TbxWdiLimitL.Text = BD.WDI_AF_LimitLower.ToString();
            Tbx_WDIAF_Channel.Text = BD.WDI_AF_LightChannel.ToString();
            Tbx_WDIAF_Current.Text = BD.WDI_AF_LightCurrent.ToString();
            Tbx_WDIAF_uPWM.Text = BD.WDI_AF_LightuPWM.ToString();

            //WDI LED
            bool isDC = (BD.WDI_LED_Mode == 0);
            Rbtn_DC.Checked = isDC;
            Rbtn_PaulseFollow.Checked = !isDC;
            TbxBrightness.Text = BD.WDI_LED_Brightness.ToString();
            BarBrightness.Value = BD.WDI_LED_Brightness;

            //DarkField
            Cbx_DarkField_Channel.Text = BD.Gardasoft_Channel.ToString();
            Tbx_DarkField_PulseWidth.Text = BD.Gardasoft_PulseWidth.ToString();
            Tbx_DarkField_TriggerDelay.Text = BD.Gardasoft_TriggerDelay.ToString();
            Tbx_DarkField_OuputCurrent.Text = BD.Gardasoft_OutputCurrent.ToString();
            Tbx_DarkField_ReTriggerDelay.Text = BD.Gardasoft_ReTriggerDelay.ToString();
        }

        #region Log

        private void SaveLog(string Log, bool isAlm = false)
        {
            if (isAlm)
            {
                this.Log.Error(Log);
            }
            else
            {
                this.Log.General(Log);
            }
        }

        private void WDI_AF_WriteLog(string Log, bool isAlm = false)
        {
            SaveLog($"[WDI AF] {Log}", isAlm);
        }

        private void WDI_LED_WriteLog(string Log, bool isAlm = false)
        {
            SaveLog($"[WDI LED] {Log}", isAlm);
        }

        private void Dark_Field_WriteLog(string Log, bool isAlm = false)
        {
            SaveLog($"[Dark Field] {Log}", isAlm);
        }

        private void Revo_WriteLog(string Log, bool isAlm)
        {
            SaveLog($"[Revo] {Log}", isAlm);
        }


        #endregion

        #region Status

        private void WDI_AF_Ctrl_IsConnectEvent(bool isConnect)
        {
            Label Ctrl = LabelAF;

            if (isConnect)
            {
                Ctrl.Invoke(new Action(() => Ctrl.BackColor = Color.Green));
            }
            else
            {
                Ctrl.Invoke(new Action(() => Ctrl.BackColor = Color.Gray));
            }
        }

        private void WDI_LED_IsConnectEvent(bool isConnect)
        {
            Label Ctrl = LabelLED;

            if (isConnect)
            {
                Ctrl.Invoke(new Action(() => Ctrl.BackColor = Color.Green));
            }
            else
            {
                Ctrl.Invoke(new Action(() => Ctrl.BackColor = Color.Gray));
            }
        }

        private void Dark_Field_IsConnectEvent(bool isConnect)
        {
            Label Ctrl = LabelDarkField;

            if (isConnect)
            {
                Ctrl.Invoke(new Action(() => Ctrl.BackColor = Color.Green));
            }
            else
            {
                Ctrl.Invoke(new Action(() => Ctrl.BackColor = Color.Gray));
            }
        }

        private void Revo_IsConnectEvent(bool isConnect)
        {
            Label Ctrl = LabelRevo;

            if (isConnect)
            {
                Ctrl.Invoke(new Action(() => Ctrl.BackColor = Color.Green));
            }
            else
            {
                Ctrl.Invoke(new Action(() => Ctrl.BackColor = Color.Gray));
            }
        }


        #endregion

        #region WDI AF

        private void WDI_AF_Init()
        {
            WDI_AF_Ctrl.WriteLog -= WDI_AF_WriteLog;
            WDI_AF_Ctrl.WriteLog += WDI_AF_WriteLog;
            WDI_AF_Ctrl.IsConnectEvent -= WDI_AF_Ctrl_IsConnectEvent;
            WDI_AF_Ctrl.IsConnectEvent += WDI_AF_Ctrl_IsConnectEvent;

            int Comport = SD.WDI_AF_Comport;
            WdiRtn rtn = WDI_AF_Ctrl.ConnectPort(Comport);

            if (!rtn.ErrorOccure) WDI_AF_Ctrl.WdiOff(true);

        }

        private void LabelAF_DoubleClick(object sender, EventArgs e)
        {
            DialogResult result;
            result = MessageBox.Show("是否重新連線 - WDI AF ?", "重新連線確認", MessageBoxButtons.YesNo);

            if (result == DialogResult.Yes)
            {
                WDI_AF_Init();
            }
        }



        private void BtnWdiHome_Click(object sender, EventArgs e)
        {
            WDI_AF_Ctrl.WdiOff(true);
        }

        private void BtnWdiSetSubStrate_Click(object sender, EventArgs e)
        {
            short Substrate = (short)Cbx_WdiSubStrate.SelectedIndex;
            string SubstrateStr = Cbx_WdiSubStrate.Text;

            WDI_AF_Ctrl.SetSubStrate(Substrate);
        }

        private void BtnWdiGetSubStrate_Click(object sender, EventArgs e)
        {
            short Substrate = -1;
            string[] SubstrateStr = { "A", "B", "C", "D", "E" };

            WdiRtn Result_WDI = WDI_AF_Ctrl.GetSubStrate(ref Substrate);

            if (Result_WDI.ErrorOccure != true)
            {
                TbxWdiSubstrate.Text = SubstrateStr[Substrate];
            }
            else
            {
                TbxWdiSubstrate.Text = "";
            }
        }

        private void BtnWdiOn_Click(object sender, EventArgs e)
        {
            int initPos = Convert.ToInt32(TbxWdiDefZ.Text);
            int DelayTime = SD.WDI_AF_MoveDelay;
            int UpperLimit = Convert.ToInt32(TbxWdiLimitU.Text);
            int LowerLimit = Convert.ToInt32(TbxWdiLimitL.Text);


            WDI_AF_Ctrl.WdiOn(initPos, DelayTime, UpperLimit, LowerLimit);

            BD.WDI_AF_ZPos = initPos;
            BD.WDI_AF_LimitUpper = UpperLimit;
            BD.WDI_AF_LimitLower = LowerLimit;
            BD.Create(BD, BackupDataPath);
        }

        private void BtnWdiOff_Click(object sender, EventArgs e)
        {
            WDI_AF_Ctrl.WdiOff();
        }

        private void BtnWdiRead_Click(object sender, EventArgs e)
        {
            double Pos = 0;
            WDI_AF_Ctrl.Read_Pos(ref Pos);
            TbxWdiPos.Text = Pos.ToString();
        }

        private void BtnAFMove_Click(object sender, EventArgs e)
        {
            try
            {
                WdiRtn rtn = WDI_AF_Ctrl.WdiOff();

                if (!rtn.ErrorOccure)
                {
                    double Pos = Convert.ToDouble(TbxWdiDefZ.Text);
                    rtn = WDI_AF_Ctrl.Move(AFzMoveType.ABS, Pos);

                    BD.WDI_AF_ZPos = Pos;
                    BD.Create(BD, BackupDataPath);

                }
            }
            catch (Exception ex)
            {
                SaveLog($"{ex.Message}", true);
            }
        }

        private void Btn_WDIAF_SetLED_Click(object sender, EventArgs e)
        {
            try
            {
                short Channel = Convert.ToInt16(Tbx_WDIAF_Channel.Text);
                ushort Current = Convert.ToUInt16(Tbx_WDIAF_Current.Text);
                ushort uPWM = Convert.ToUInt16(Tbx_WDIAF_uPWM.Text);

                WdiRtn rtn = WDI_AF_Ctrl.Set_Led(Channel, Current, uPWM);

                BD.WDI_AF_LightChannel = Channel;
                BD.WDI_AF_LightCurrent = Current;
                BD.WDI_AF_LightuPWM = uPWM;
                BD.Create(BD, BackupDataPath);

            }
            catch (Exception ex)
            {
                SaveLog($"{ex.Message}", true);
            }
        }

        #endregion

        #region WDI LED 

        private void WDI_LED_Init()
        {
            WDI_LED = new WDI_Led_Ctrl();
            WDI_LED.WriteLog -= WDI_LED_WriteLog;
            WDI_LED.WriteLog += WDI_LED_WriteLog;
            WDI_LED.IsConnectEvent -= WDI_LED_IsConnectEvent;
            WDI_LED.IsConnectEvent += WDI_LED_IsConnectEvent;

            bool Rtn = WDI_LED.Connect(SD.WDI_LED_ComPort);


        }

        private void LabelLED_DoubleClick(object sender, EventArgs e)
        {
            DialogResult result;
            result = MessageBox.Show("是否重新連線 - WDI LED ?", "重新連線確認", MessageBoxButtons.YesNo);

            if (result == DialogResult.Yes)
            {
                WDI_LED_Init();
            }
        }

        private void BarBrightness_Scroll(object sender, EventArgs e)
        {
            TbxBrightness.Text = BarBrightness.Value.ToString();
        }

        private void TbxBrightness_Validated(object sender, EventArgs e)
        {
            try
            {
                (BarBrightness.Value) = Convert.ToInt32(TbxBrightness.Text);
            }
            catch
            {
                MessageBox.Show("數值錯誤");
            }
        }

        private void TbxBrightness_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)

            {
                if (TbxBrightness.Focused)
                {
                    BarBrightness.Focus();
                }
            }
        }

        private void BtnLEDSendCMD_Click(object sender, EventArgs e)
        {
            if (Rbtn_Off.Checked)
            {
                WDI_LED.TurnOff();
            }
            else
            {
                int Mode = 0;

                if (Rbtn_DC.Checked)
                {
                    Mode = 0;
                }

                if (Rbtn_PaulseFollow.Checked)
                {
                    Mode = 1;
                }

                if (Rbtn_PaulseTrigger.Checked)
                {
                    Mode = 2;
                }

                int Brightness = BarBrightness.Value;

                if(Mode == 0 || Mode ==1)
                {
                    WDI_LED.SetMode(Mode, Brightness);
                }
                else
                {
                    int TriggerDelay =Convert.ToInt32( TbxTriggerDelay.Text);
                    int Duration = Convert.ToInt32(TbxDuration.Text);

                    WDI_LED.SetTriggerMode(Brightness, TriggerDelay, Duration);

                }

                BD.WDI_LED_Mode = Mode;
                BD.WDI_LED_Brightness = Brightness;
                BD.Create(BD, BackupDataPath);
            }
        }

        #endregion

        #region Dark Field

        public void Dark_Field_Init()
        {
            Dark_Field = new Gardasoft_Light_Ctrl();

            Dark_Field.WriteLog -= Dark_Field_WriteLog;
            Dark_Field.WriteLog += Dark_Field_WriteLog;

            Dark_Field.IsConnectEvent -= Dark_Field_IsConnectEvent;
            Dark_Field.IsConnectEvent += Dark_Field_IsConnectEvent;

            Dark_Field.CltConnect(SD.DarkField_IP, SD.DarkField_Port);
        }

        private void LabelDarkField_DoubleClick(object sender, EventArgs e)
        {
            DialogResult result;
            result = MessageBox.Show("是否重新連線 - Dark Field ?", "重新連線確認", MessageBoxButtons.YesNo);

            if (result == DialogResult.Yes)
            {
                Dark_Field_Init();
            }
        }

        private void Btn_DarkField_Send_Click(object sender, EventArgs e)
        {
            try
            {
                int Channel = Cbx_DarkField_Channel.SelectedIndex;
                int PulseWidth = Convert.ToInt32(Tbx_DarkField_PulseWidth.Text);
                int TrggerDelay = Convert.ToInt32(Tbx_DarkField_TriggerDelay.Text);
                int Current = Convert.ToInt32(Tbx_DarkField_OuputCurrent.Text);
                int ReTriggerDelay = Convert.ToInt32(Tbx_DarkField_ReTriggerDelay.Text);

                Dark_Field.PulsedOutputMode(Channel, PulseWidth, TrggerDelay, Current, ReTriggerDelay);

                BD.Gardasoft_Channel = Channel;
                BD.Gardasoft_PulseWidth = PulseWidth;
                BD.Gardasoft_TriggerDelay = TrggerDelay;
                BD.Gardasoft_OutputCurrent = Current;
                BD.Gardasoft_ReTriggerDelay = ReTriggerDelay;

                BD.Create(BD, BackupDataPath);

            }
            catch (Exception ex)
            {
                MessageBox.Show($"數值錯誤 , {ex.Message}");

            }
        }


        #endregion

        #region Revo

        private void Revo_Init()
        {
            Revo = new Revo_Ctrl();
            Revo.WriteLog += Revo_WriteLog;
            Revo.IsConnectEvent += Revo_IsConnectEvent;

            Revo.Connect(SD.Revo_ComPort);
        }

        private void LabelRevo_DoubleClick(object sender, EventArgs e)
        {
            DialogResult result;
            result = MessageBox.Show("是否重新連線 - 鼻輪 ?", "重新連線確認", MessageBoxButtons.YesNo);

            if (result == DialogResult.Yes)
            {
                Revo_Init();
            }
        }

        private void Btn_Revo_ReadStatus_Click(object sender, EventArgs e)
        {
            Revo.ReadStatus();
        }

        private void Btn_Revo_Move_Click(object sender, EventArgs e)
        {
            int Idx = -1;
            if (Rbtn_Revo_A.Checked) Idx = 0;
            if (Rbtn_Revo_B.Checked) Idx = 1;
            if (Rbtn_Revo_C.Checked) Idx = 2;
            if (Rbtn_Revo_D.Checked) Idx = 3;
            Revo.ChangeLens(Idx);
        }

        private void Btn_Revo_Stop_Click(object sender, EventArgs e)
        {
            Revo.ChangeStop();
        }

        #endregion

        private void Set_NotifyIcon()
        {
            this._NotifyIcon = new System.Windows.Forms.NotifyIcon(this.components);
            this._NotifyIcon.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.NotifyIcon_MouseDoubleClick);
            Bitmap bmp = Properties.Resources.Icon;
            this._NotifyIcon.Icon = Icon.FromHandle(bmp.GetHicon());
            this._NotifyIcon.Text = $"光學週邊控制 - {DeviceName}";
        }

        private void NotifyIcon_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            this.Show();
            this.WindowState = FormWindowState.Normal;
            this._NotifyIcon.Visible = false;
        }

        private void MainForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            e.Cancel = true;

            if (DialogResult.Yes == MessageBox.Show("確定要關閉程式??", "關閉確認", MessageBoxButtons.YesNo, MessageBoxIcon.Question))
            {
                Log.Dispose();
                SvrClose();
                e.Cancel = false;
            }

            if (e.Cancel)
            {
                return;
            }
        }

        private void BtnZoom_Click(object sender, EventArgs e)
        {
            if (this.Height == MaxHeight)
            {
                this.Height = MinHeight;
                BtnZoom.Text = MinStr;
            }
            else
            {
                this.Height = MaxHeight;
                BtnZoom.Text = MaxStr;
            }
        }

        private void BtnMin_Click(object sender, EventArgs e)
        {
            this.Hide();
            this._NotifyIcon.Visible = true;
        }

        private void BtnSaveConfig_Click(object sender, EventArgs e)
        {
            SD.Create(SD, ConfigPath);
            MessageBox.Show("Config Saved !!");
        }

        private void LabelSvr_DoubleClick(object sender, EventArgs e)
        {
            DialogResult result;
            result = MessageBox.Show("是否重新連線 - Server ?", "重新連線確認", MessageBoxButtons.YesNo);

            if (result == DialogResult.Yes)
            {
                Svr_Init();
            }
        }

        private void MainForm_SizeChanged(object sender, EventArgs e)
        {
            if (this.WindowState == FormWindowState.Minimized)//捕獲窗體最大化事件
            {
                this.Hide();
                this._NotifyIcon.Visible = true;
            }
        }
    }
}
