﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml;

public static class IniManager
{
    [DllImport("kernel32")]
    private static extern long WritePrivateProfileString(string section, string key, string lpString, string lpFileName);

    [DllImport("kernel32")]
    private static extern int GetPrivateProfileString(string section, string key, string lpDefault, StringBuilder lpReturnedString, int nSize, string lpFileName);


    // read ini date depend on section and key
    public static string ReadIni(string filePath, string section, string key, string defaultValue)
    {

        int bufferSize = 1024;
        StringBuilder lpReturnedString = new StringBuilder(bufferSize);

        lpReturnedString.Clear();
        GetPrivateProfileString(section, key, defaultValue, lpReturnedString, bufferSize, filePath);

        string Result = (lpReturnedString.ToString());
        return Result;
    }

    // write ini data depend on section and key
    public static void WriteIni(string filePath, string section, string key, string defaultValue)
    {
        WritePrivateProfileString(section, key, defaultValue, filePath);
    }
}

public static class _7zTool
{
    public static void Compress(string SourceExe, string CompressFile, string CompressPath)
    {
        Process process = new Process();
        process.StartInfo.FileName = SourceExe;
        process.StartInfo.Arguments = "a -tzip " + CompressPath + " " + CompressFile;
        process.Start();
    }

    public static void DeCompress(string SourceExe, string DeCompressFile, string DeCompressPath)
    {
        Process process = new Process();
        process.StartInfo.FileName = SourceExe;
        process.StartInfo.Arguments = "e " + DeCompressFile + " -o" + DeCompressPath + " -y";
        process.Start();
    }
}

public class BitmapPlus
{
    private Bitmap bmp_ = null;
    private BitmapData img_ = null;

    public BitmapPlus()
    {

    }
    public BitmapPlus(Bitmap original)
    {
        bmp_ = original;
    }

    public void BeginAccess()
    {
        img_ = bmp_.LockBits(new Rectangle(0, 0, bmp_.Width, bmp_.Height),
            System.Drawing.Imaging.ImageLockMode.ReadWrite,
            //System.Drawing.Imaging.PixelFormat.Format24bppRgb);
            bmp_.PixelFormat);
    }

    public void EndAccess()
    {
        if (img_ != null)
        {
            bmp_.UnlockBits(img_);
            img_ = null;
        }
    }

    public void SetPixel(int x, int y, Color c)
    {
        if (img_ == null)
        {
            bmp_.SetPixel(x, y, c);
            return;
        }
        IntPtr adr = img_.Scan0;
        int pos = x * 3 + img_.Stride * y;
        System.Runtime.InteropServices.Marshal.WriteByte(adr, pos + 0, c.B);
        System.Runtime.InteropServices.Marshal.WriteByte(adr, pos + 1, c.G);
        System.Runtime.InteropServices.Marshal.WriteByte(adr, pos + 2, c.R);
    }

    public void SetPixel(int x, int y, byte b)
    {
        if (img_ == null)
        {
            bmp_.SetPixel(x, y, Color.FromArgb(b, b, b));
            return;
        }
        IntPtr adr = img_.Scan0;
        //int pos = x + img_.Stride * y;
        //System.Runtime.InteropServices.Marshal.WriteByte(adr, pos, b);
        int pos = x * 3 + img_.Stride * y;
        System.Runtime.InteropServices.Marshal.WriteByte(adr, pos + 0, b);
        System.Runtime.InteropServices.Marshal.WriteByte(adr, pos + 1, b);
        System.Runtime.InteropServices.Marshal.WriteByte(adr, pos + 2, b);
    }



    public Bitmap PGrayToColor(Bitmap src)
    {

        Bitmap a = new Bitmap(src);
        Rectangle rect = new Rectangle(0, 0, a.Width, a.Height);
        System.Drawing.Imaging.BitmapData bmpData = a.LockBits(rect, System.Drawing.Imaging.ImageLockMode.ReadWrite, System.Drawing.Imaging.PixelFormat.Format24bppRgb);
        int stride = bmpData.Stride;
        unsafe
        {
            byte* pIn = (byte*)bmpData.Scan0.ToPointer();
            byte* P;
            int R, G, B;
            int temp = 0;
            for (int y = 0; y < a.Height; y++)
            {
                for (int x = 0; x < a.Width; x++)
                {
                    P = pIn;
                    B = P[0];
                    G = P[1];
                    R = P[2];
                    temp = (byte)(B * 0.114 + G * 0.587 + R * 0.299);
                    if (temp >= 0 && temp <= 63)
                    {
                        P[2] = 0;
                        P[1] = (byte)(254 - 4 * temp);
                        P[0] = (byte)255;
                    }
                    if (temp >= 64 && temp <= 127)
                    {
                        P[2] = 0;
                        P[1] = (byte)(4 * temp - 254);
                        P[0] = (byte)(510 - 4 * temp);
                    }
                    if (temp >= 128 && temp <= 191)
                    {
                        P[2] = (byte)(4 * temp - 510);
                        P[1] = (byte)(255);
                        P[0] = (byte)0;
                    }
                    if (temp >= 192 && temp <= 255)
                    {
                        P[2] = (byte)255;
                        P[1] = (byte)(1022 - 4 * temp);
                        P[0] = (byte)0;
                    }
                    pIn += 3;
                }
                pIn += stride - a.Width * 3;
            }
        }
        a.UnlockBits(bmpData);
        return a;

    }
}
public class TimeManager
{
    private DateTime SetTime;
    private int DelayTime = 1000;

    public void SetDelay(int Time)
    {
        SetTime = DateTime.Now;
        DelayTime = Time;
    }

    public bool IsTimeOut()
    {
        DateTime NowTime = DateTime.Now;
        return (NowTime - SetTime).TotalMilliseconds >= DelayTime;
    }
}


public static class XMLReadandParse
{
    public static List<string> ReadXml(string Path, string SectionName)
    {
        List<string> Data = new List<string>();
        // Start with XmlReader object  
        //here, we try to setup Stream between the XML file nad xmlReader  
        using (XmlReader reader = XmlReader.Create(Path))
        {
            while (reader.Read())
            {
                if (reader.IsStartElement())
                {
                    //return only when you have START tag  
                    if (reader.Name.ToString() == SectionName)
                    {
                        Data.Add(reader.ReadString());
                    }

                }
            }

            return Data;
        }
    }
}

public static class DirManager
{
    public static void CopyDirToDir(string sourceDir, string destDir)
    {
        try
        {
            DirectoryInfo sourceDireInfo = new DirectoryInfo(sourceDir);
            List<FileInfo> fileList = new List<FileInfo>();
            GetFileList(sourceDireInfo, fileList);
            List<DirectoryInfo> dirList = new List<DirectoryInfo>();
            GetDirList(sourceDireInfo, dirList);
            foreach (DirectoryInfo dir in dirList)
            {
                string m = dir.FullName;
                string n = m.Replace(sourceDir, destDir);
                if (!Directory.Exists(n))
                {
                    Directory.CreateDirectory(n);
                }
            }
            foreach (FileInfo fileInfo in fileList)
            {
                string m = fileInfo.FullName;
                string n = m.Replace(sourceDir, destDir);
                File.Copy(m, n, true);
            }
        }
        catch (Exception ex) 
        {

            MessageBox.Show(ex.Message);
        }
      
    }

    private static void GetFileList(DirectoryInfo dir, List<FileInfo> fileList)
    {
        fileList.AddRange(dir.GetFiles());
        foreach (DirectoryInfo directory in dir.GetDirectories()) GetFileList(directory, fileList);
    }
    private static void GetDirList(DirectoryInfo dir, List<DirectoryInfo> dirList)
    {
        dirList.AddRange(dir.GetDirectories());
        foreach (DirectoryInfo directory in dir.GetDirectories()) GetDirList(directory, dirList);
    }
}
